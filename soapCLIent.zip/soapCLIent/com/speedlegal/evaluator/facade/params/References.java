
package com.speedlegal.evaluator.facade.params;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Logic" type="{http://speedlegal.com/evaluator/facade/params}Reference" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Style" type="{http://speedlegal.com/evaluator/facade/params}Reference" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Module" type="{http://speedlegal.com/evaluator/facade/params}Reference" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Resource" type="{http://speedlegal.com/evaluator/facade/params}Reference" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "logic",
    "style",
    "module",
    "resource"
})
@XmlRootElement(name = "References")
public class References {

    @XmlElement(name = "Logic")
    protected List<Reference> logic;
    @XmlElement(name = "Style")
    protected List<Reference> style;
    @XmlElement(name = "Module")
    protected List<Reference> module;
    @XmlElement(name = "Resource")
    protected List<Reference> resource;

    /**
     * Gets the value of the logic property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the logic property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLogic().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Reference }
     * 
     * 
     */
    public List<Reference> getLogic() {
        if (logic == null) {
            logic = new ArrayList<Reference>();
        }
        return this.logic;
    }

    /**
     * Gets the value of the style property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the style property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStyle().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Reference }
     * 
     * 
     */
    public List<Reference> getStyle() {
        if (style == null) {
            style = new ArrayList<Reference>();
        }
        return this.style;
    }

    /**
     * Gets the value of the module property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the module property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getModule().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Reference }
     * 
     * 
     */
    public List<Reference> getModule() {
        if (module == null) {
            module = new ArrayList<Reference>();
        }
        return this.module;
    }

    /**
     * Gets the value of the resource property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the resource property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getResource().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Reference }
     * 
     * 
     */
    public List<Reference> getResource() {
        if (resource == null) {
            resource = new ArrayList<Reference>();
        }
        return this.resource;
    }

}
