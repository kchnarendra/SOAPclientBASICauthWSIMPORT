
package com.speedlegal.evaluator.facade.params;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *       &lt;/sequence>
 *       &lt;attribute name="includeReferences" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="includeLogicItems" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="includeLogicDetail" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="includeDataTypes" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="includeMetaInfo" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@XmlRootElement(name = "DescribePreferences")
public class DescribePreferences {

    @XmlAttribute(name = "includeReferences")
    protected Boolean includeReferences;
    @XmlAttribute(name = "includeLogicItems")
    protected Boolean includeLogicItems;
    @XmlAttribute(name = "includeLogicDetail")
    protected Boolean includeLogicDetail;
    @XmlAttribute(name = "includeDataTypes")
    protected Boolean includeDataTypes;
    @XmlAttribute(name = "includeMetaInfo")
    protected Boolean includeMetaInfo;

    /**
     * Gets the value of the includeReferences property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIncludeReferences() {
        return includeReferences;
    }

    /**
     * Sets the value of the includeReferences property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIncludeReferences(Boolean value) {
        this.includeReferences = value;
    }

    /**
     * Gets the value of the includeLogicItems property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIncludeLogicItems() {
        return includeLogicItems;
    }

    /**
     * Sets the value of the includeLogicItems property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIncludeLogicItems(Boolean value) {
        this.includeLogicItems = value;
    }

    /**
     * Gets the value of the includeLogicDetail property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIncludeLogicDetail() {
        return includeLogicDetail;
    }

    /**
     * Sets the value of the includeLogicDetail property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIncludeLogicDetail(Boolean value) {
        this.includeLogicDetail = value;
    }

    /**
     * Gets the value of the includeDataTypes property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIncludeDataTypes() {
        return includeDataTypes;
    }

    /**
     * Sets the value of the includeDataTypes property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIncludeDataTypes(Boolean value) {
        this.includeDataTypes = value;
    }

    /**
     * Gets the value of the includeMetaInfo property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIncludeMetaInfo() {
        return includeMetaInfo;
    }

    /**
     * Sets the value of the includeMetaInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIncludeMetaInfo(Boolean value) {
        this.includeMetaInfo = value;
    }

}
