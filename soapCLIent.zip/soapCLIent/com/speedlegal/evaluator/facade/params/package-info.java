@javax.xml.bind.annotation.XmlSchema(namespace = "http://speedlegal.com/evaluator/facade/params", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.speedlegal.evaluator.facade.params;
