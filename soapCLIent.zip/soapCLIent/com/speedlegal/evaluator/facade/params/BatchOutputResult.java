
package com.speedlegal.evaluator.facade.params;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAnyElement;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import org.w3c.dom.Element;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://speedlegal.com/evaluator/facade/params}GeneratedDocument" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="GenerationFault" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;any processContents='skip' namespace='##other'/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="incidentCode" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *       &lt;attribute name="format" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "generatedDocument",
    "generationFault"
})
@XmlRootElement(name = "BatchOutputResult")
public class BatchOutputResult {

    @XmlElement(name = "GeneratedDocument")
    protected List<GeneratedDocument> generatedDocument;
    @XmlElement(name = "GenerationFault")
    protected BatchOutputResult.GenerationFault generationFault;
    @XmlAttribute(name = "format", required = true)
    protected String format;

    /**
     * Gets the value of the generatedDocument property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the generatedDocument property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGeneratedDocument().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GeneratedDocument }
     * 
     * 
     */
    public List<GeneratedDocument> getGeneratedDocument() {
        if (generatedDocument == null) {
            generatedDocument = new ArrayList<GeneratedDocument>();
        }
        return this.generatedDocument;
    }

    /**
     * Gets the value of the generationFault property.
     * 
     * @return
     *     possible object is
     *     {@link BatchOutputResult.GenerationFault }
     *     
     */
    public BatchOutputResult.GenerationFault getGenerationFault() {
        return generationFault;
    }

    /**
     * Sets the value of the generationFault property.
     * 
     * @param value
     *     allowed object is
     *     {@link BatchOutputResult.GenerationFault }
     *     
     */
    public void setGenerationFault(BatchOutputResult.GenerationFault value) {
        this.generationFault = value;
    }

    /**
     * Gets the value of the format property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormat() {
        return format;
    }

    /**
     * Sets the value of the format property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormat(String value) {
        this.format = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;any processContents='skip' namespace='##other'/>
     *       &lt;/sequence>
     *       &lt;attribute name="incidentCode" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "any"
    })
    public static class GenerationFault {

        @XmlAnyElement
        protected Element any;
        @XmlAttribute(name = "incidentCode", required = true)
        protected String incidentCode;

        /**
         * Gets the value of the any property.
         * 
         * @return
         *     possible object is
         *     {@link Element }
         *     
         */
        public Element getAny() {
            return any;
        }

        /**
         * Sets the value of the any property.
         * 
         * @param value
         *     allowed object is
         *     {@link Element }
         *     
         */
        public void setAny(Element value) {
            this.any = value;
        }

        /**
         * Gets the value of the incidentCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getIncidentCode() {
            return incidentCode;
        }

        /**
         * Sets the value of the incidentCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setIncidentCode(String value) {
            this.incidentCode = value;
        }

    }

}
