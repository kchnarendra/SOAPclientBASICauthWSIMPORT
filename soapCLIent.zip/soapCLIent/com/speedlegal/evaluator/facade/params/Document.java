
package com.speedlegal.evaluator.facade.params;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *       &lt;/sequence>
 *       &lt;attribute name="resourcePath" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="versionReference" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="useLatest" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="usePublished" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@XmlRootElement(name = "Document")
public class Document {

    @XmlAttribute(name = "resourcePath")
    protected String resourcePath;
    @XmlAttribute(name = "versionReference")
    protected String versionReference;
    @XmlAttribute(name = "useLatest")
    protected Boolean useLatest;
    @XmlAttribute(name = "usePublished")
    protected Boolean usePublished;

    /**
     * Gets the value of the resourcePath property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResourcePath() {
        return resourcePath;
    }

    /**
     * Sets the value of the resourcePath property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResourcePath(String value) {
        this.resourcePath = value;
    }

    /**
     * Gets the value of the versionReference property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVersionReference() {
        return versionReference;
    }

    /**
     * Sets the value of the versionReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVersionReference(String value) {
        this.versionReference = value;
    }

    /**
     * Gets the value of the useLatest property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isUseLatest() {
        return useLatest;
    }

    /**
     * Sets the value of the useLatest property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setUseLatest(Boolean value) {
        this.useLatest = value;
    }

    /**
     * Gets the value of the usePublished property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isUsePublished() {
        return usePublished;
    }

    /**
     * Sets the value of the usePublished property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setUsePublished(Boolean value) {
        this.usePublished = value;
    }

}
