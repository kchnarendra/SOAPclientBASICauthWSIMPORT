
package com.speedlegal.evaluator.facade.params;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://speedlegal.com/evaluator/facade/params}Document"/>
 *         &lt;element ref="{http://speedlegal.com/evaluator/facade/params}DescribePreferences" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "document",
    "describePreferences"
})
@XmlRootElement(name = "DescribeRequest")
public class DescribeRequest {

    @XmlElement(name = "Document", required = true)
    protected Document document;
    @XmlElement(name = "DescribePreferences")
    protected DescribePreferences describePreferences;

    /**
     * Gets the value of the document property.
     * 
     * @return
     *     possible object is
     *     {@link Document }
     *     
     */
    public Document getDocument() {
        return document;
    }

    /**
     * Sets the value of the document property.
     * 
     * @param value
     *     allowed object is
     *     {@link Document }
     *     
     */
    public void setDocument(Document value) {
        this.document = value;
    }

    /**
     * Gets the value of the describePreferences property.
     * 
     * @return
     *     possible object is
     *     {@link DescribePreferences }
     *     
     */
    public DescribePreferences getDescribePreferences() {
        return describePreferences;
    }

    /**
     * Sets the value of the describePreferences property.
     * 
     * @param value
     *     allowed object is
     *     {@link DescribePreferences }
     *     
     */
    public void setDescribePreferences(DescribePreferences value) {
        this.describePreferences = value;
    }

}
