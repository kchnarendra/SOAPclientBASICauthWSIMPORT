
package com.speedlegal.evaluator.facade.params;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://speedlegal.com/evaluator/facade/params}References" minOccurs="0"/>
 *         &lt;element name="LogicItems" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element ref="{http://speedlegal.com/evaluator/facade/params}LogicItem" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="DataTypes" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element ref="{http://speedlegal.com/evaluator/facade/params}DataType" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *       &lt;attribute name="title" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="description" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="author" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="keywords" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="published" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="resourcePath" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="versionReference" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "references",
    "logicItems",
    "dataTypes"
})
@XmlRootElement(name = "DescribeResponse")
public class DescribeResponse {

    @XmlElement(name = "References")
    protected References references;
    @XmlElement(name = "LogicItems")
    protected DescribeResponse.LogicItems logicItems;
    @XmlElement(name = "DataTypes")
    protected DescribeResponse.DataTypes dataTypes;
    @XmlAttribute(name = "title")
    protected String title;
    @XmlAttribute(name = "description")
    protected String description;
    @XmlAttribute(name = "author")
    protected String author;
    @XmlAttribute(name = "keywords")
    protected String keywords;
    @XmlAttribute(name = "published")
    protected Boolean published;
    @XmlAttribute(name = "resourcePath")
    protected String resourcePath;
    @XmlAttribute(name = "versionReference")
    protected String versionReference;

    /**
     * Gets the value of the references property.
     * 
     * @return
     *     possible object is
     *     {@link References }
     *     
     */
    public References getReferences() {
        return references;
    }

    /**
     * Sets the value of the references property.
     * 
     * @param value
     *     allowed object is
     *     {@link References }
     *     
     */
    public void setReferences(References value) {
        this.references = value;
    }

    /**
     * Gets the value of the logicItems property.
     * 
     * @return
     *     possible object is
     *     {@link DescribeResponse.LogicItems }
     *     
     */
    public DescribeResponse.LogicItems getLogicItems() {
        return logicItems;
    }

    /**
     * Sets the value of the logicItems property.
     * 
     * @param value
     *     allowed object is
     *     {@link DescribeResponse.LogicItems }
     *     
     */
    public void setLogicItems(DescribeResponse.LogicItems value) {
        this.logicItems = value;
    }

    /**
     * Gets the value of the dataTypes property.
     * 
     * @return
     *     possible object is
     *     {@link DescribeResponse.DataTypes }
     *     
     */
    public DescribeResponse.DataTypes getDataTypes() {
        return dataTypes;
    }

    /**
     * Sets the value of the dataTypes property.
     * 
     * @param value
     *     allowed object is
     *     {@link DescribeResponse.DataTypes }
     *     
     */
    public void setDataTypes(DescribeResponse.DataTypes value) {
        this.dataTypes = value;
    }

    /**
     * Gets the value of the title property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the value of the title property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTitle(String value) {
        this.title = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the author property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuthor() {
        return author;
    }

    /**
     * Sets the value of the author property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuthor(String value) {
        this.author = value;
    }

    /**
     * Gets the value of the keywords property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKeywords() {
        return keywords;
    }

    /**
     * Sets the value of the keywords property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKeywords(String value) {
        this.keywords = value;
    }

    /**
     * Gets the value of the published property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isPublished() {
        return published;
    }

    /**
     * Sets the value of the published property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPublished(Boolean value) {
        this.published = value;
    }

    /**
     * Gets the value of the resourcePath property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResourcePath() {
        return resourcePath;
    }

    /**
     * Sets the value of the resourcePath property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResourcePath(String value) {
        this.resourcePath = value;
    }

    /**
     * Gets the value of the versionReference property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVersionReference() {
        return versionReference;
    }

    /**
     * Sets the value of the versionReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVersionReference(String value) {
        this.versionReference = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element ref="{http://speedlegal.com/evaluator/facade/params}DataType" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "dataType"
    })
    public static class DataTypes {

        @XmlElement(name = "DataType")
        protected List<DataType> dataType;

        /**
         * Gets the value of the dataType property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the dataType property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDataType().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link DataType }
         * 
         * 
         */
        public List<DataType> getDataType() {
            if (dataType == null) {
                dataType = new ArrayList<DataType>();
            }
            return this.dataType;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element ref="{http://speedlegal.com/evaluator/facade/params}LogicItem" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "logicItem"
    })
    public static class LogicItems {

        @XmlElement(name = "LogicItem")
        protected List<LogicItem> logicItem;

        /**
         * Gets the value of the logicItem property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the logicItem property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getLogicItem().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link LogicItem }
         * 
         * 
         */
        public List<LogicItem> getLogicItem() {
            if (logicItem == null) {
                logicItem = new ArrayList<LogicItem>();
            }
            return this.logicItem;
        }

    }

}
