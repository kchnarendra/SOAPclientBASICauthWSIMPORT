
package com.speedlegal.evaluator.facade.params;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.speedlegal.common.xml.AvailableAnswer;
import com.speedlegal.common.xml.Note;
import com.speedlegal.common.xml.Variable;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://speedlegal.com/common/xml}Variable" maxOccurs="unbounded"/>
 *         &lt;element name="QuestionText" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExampleText" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AllowedAnswer" type="{http://speedlegal.com/common/xml}AvailableAnswer" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://speedlegal.com/common/xml}Note" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="type" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="derived" use="required" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="repeater" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="repeaterOperation" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="allowsZero" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="allowsMultiple" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="topic" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="priority" type="{http://www.w3.org/2001/XMLSchema}double" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "variable",
    "questionText",
    "exampleText",
    "allowedAnswer",
    "note"
})
@XmlRootElement(name = "LogicItem")
public class LogicItem {

    @XmlElement(name = "Variable", namespace = "http://speedlegal.com/common/xml", required = true)
    protected List<Variable> variable;
    @XmlElement(name = "QuestionText")
    protected String questionText;
    @XmlElement(name = "ExampleText")
    protected String exampleText;
    @XmlElement(name = "AllowedAnswer")
    protected List<AvailableAnswer> allowedAnswer;
    @XmlElement(name = "Note", namespace = "http://speedlegal.com/common/xml")
    protected List<Note> note;
    @XmlAttribute(name = "type", required = true)
    protected String type;
    @XmlAttribute(name = "derived", required = true)
    protected boolean derived;
    @XmlAttribute(name = "repeater")
    protected String repeater;
    @XmlAttribute(name = "repeaterOperation")
    protected String repeaterOperation;
    @XmlAttribute(name = "allowsZero")
    protected Boolean allowsZero;
    @XmlAttribute(name = "allowsMultiple")
    protected Boolean allowsMultiple;
    @XmlAttribute(name = "topic")
    protected String topic;
    @XmlAttribute(name = "priority")
    protected Double priority;

    /**
     * Gets the value of the variable property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the variable property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getVariable().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Variable }
     * 
     * 
     */
    public List<Variable> getVariable() {
        if (variable == null) {
            variable = new ArrayList<Variable>();
        }
        return this.variable;
    }

    /**
     * Gets the value of the questionText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQuestionText() {
        return questionText;
    }

    /**
     * Sets the value of the questionText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQuestionText(String value) {
        this.questionText = value;
    }

    /**
     * Gets the value of the exampleText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExampleText() {
        return exampleText;
    }

    /**
     * Sets the value of the exampleText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExampleText(String value) {
        this.exampleText = value;
    }

    /**
     * Gets the value of the allowedAnswer property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the allowedAnswer property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAllowedAnswer().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AvailableAnswer }
     * 
     * 
     */
    public List<AvailableAnswer> getAllowedAnswer() {
        if (allowedAnswer == null) {
            allowedAnswer = new ArrayList<AvailableAnswer>();
        }
        return this.allowedAnswer;
    }

    /**
     * Gets the value of the note property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the note property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNote().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Note }
     * 
     * 
     */
    public List<Note> getNote() {
        if (note == null) {
            note = new ArrayList<Note>();
        }
        return this.note;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the derived property.
     * 
     */
    public boolean isDerived() {
        return derived;
    }

    /**
     * Sets the value of the derived property.
     * 
     */
    public void setDerived(boolean value) {
        this.derived = value;
    }

    /**
     * Gets the value of the repeater property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRepeater() {
        return repeater;
    }

    /**
     * Sets the value of the repeater property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRepeater(String value) {
        this.repeater = value;
    }

    /**
     * Gets the value of the repeaterOperation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRepeaterOperation() {
        return repeaterOperation;
    }

    /**
     * Sets the value of the repeaterOperation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRepeaterOperation(String value) {
        this.repeaterOperation = value;
    }

    /**
     * Gets the value of the allowsZero property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isAllowsZero() {
        return allowsZero;
    }

    /**
     * Sets the value of the allowsZero property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAllowsZero(Boolean value) {
        this.allowsZero = value;
    }

    /**
     * Gets the value of the allowsMultiple property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isAllowsMultiple() {
        return allowsMultiple;
    }

    /**
     * Sets the value of the allowsMultiple property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAllowsMultiple(Boolean value) {
        this.allowsMultiple = value;
    }

    /**
     * Gets the value of the topic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTopic() {
        return topic;
    }

    /**
     * Sets the value of the topic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTopic(String value) {
        this.topic = value;
    }

    /**
     * Gets the value of the priority property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setPriority(Double value) {
        this.priority = value;
    }

}
