
package com.speedlegal.evaluator.facade.params;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.speedlegal.common.xml.Amendments;
import com.speedlegal.common.xml.OutputPreferences;
import com.speedlegal.common.xml.Workflow;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://speedlegal.com/evaluator/facade/params}Document"/>
 *         &lt;element ref="{http://speedlegal.com/evaluator/facade/params}InterviewPreferences" minOccurs="0"/>
 *         &lt;element ref="{http://speedlegal.com/evaluator/facade/params}FeatureSet" minOccurs="0"/>
 *         &lt;element ref="{http://speedlegal.com/common/xml}OutputPreferences" minOccurs="0"/>
 *         &lt;element ref="{http://speedlegal.com/common/xml}Workflow" minOccurs="0"/>
 *         &lt;element ref="{http://speedlegal.com/common/xml}Amendments" minOccurs="0"/>
 *         &lt;element ref="{http://speedlegal.com/evaluator/facade/params}Answers" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "document",
    "interviewPreferences",
    "featureSet",
    "outputPreferences",
    "workflow",
    "amendments",
    "answers"
})
@XmlRootElement(name = "EvaluationRequest")
public class EvaluationRequest {

    @XmlElement(name = "Document", required = true)
    protected Document document;
    @XmlElement(name = "InterviewPreferences")
    protected InterviewPreferences interviewPreferences;
    @XmlElement(name = "FeatureSet")
    protected FeatureSet featureSet;
    @XmlElement(name = "OutputPreferences", namespace = "http://speedlegal.com/common/xml")
    protected OutputPreferences outputPreferences;
    @XmlElement(name = "Workflow", namespace = "http://speedlegal.com/common/xml")
    protected Workflow workflow;
    @XmlElement(name = "Amendments", namespace = "http://speedlegal.com/common/xml")
    protected Amendments amendments;
    @XmlElement(name = "Answers")
    protected Answers answers;

    /**
     * Gets the value of the document property.
     * 
     * @return
     *     possible object is
     *     {@link Document }
     *     
     */
    public Document getDocument() {
        return document;
    }

    /**
     * Sets the value of the document property.
     * 
     * @param value
     *     allowed object is
     *     {@link Document }
     *     
     */
    public void setDocument(Document value) {
        this.document = value;
    }

    /**
     * Gets the value of the interviewPreferences property.
     * 
     * @return
     *     possible object is
     *     {@link InterviewPreferences }
     *     
     */
    public InterviewPreferences getInterviewPreferences() {
        return interviewPreferences;
    }

    /**
     * Sets the value of the interviewPreferences property.
     * 
     * @param value
     *     allowed object is
     *     {@link InterviewPreferences }
     *     
     */
    public void setInterviewPreferences(InterviewPreferences value) {
        this.interviewPreferences = value;
    }

    /**
     * Gets the value of the featureSet property.
     * 
     * @return
     *     possible object is
     *     {@link FeatureSet }
     *     
     */
    public FeatureSet getFeatureSet() {
        return featureSet;
    }

    /**
     * Sets the value of the featureSet property.
     * 
     * @param value
     *     allowed object is
     *     {@link FeatureSet }
     *     
     */
    public void setFeatureSet(FeatureSet value) {
        this.featureSet = value;
    }

    /**
     * Gets the value of the outputPreferences property.
     * 
     * @return
     *     possible object is
     *     {@link OutputPreferences }
     *     
     */
    public OutputPreferences getOutputPreferences() {
        return outputPreferences;
    }

    /**
     * Sets the value of the outputPreferences property.
     * 
     * @param value
     *     allowed object is
     *     {@link OutputPreferences }
     *     
     */
    public void setOutputPreferences(OutputPreferences value) {
        this.outputPreferences = value;
    }

    /**
     * Gets the value of the workflow property.
     * 
     * @return
     *     possible object is
     *     {@link Workflow }
     *     
     */
    public Workflow getWorkflow() {
        return workflow;
    }

    /**
     * Sets the value of the workflow property.
     * 
     * @param value
     *     allowed object is
     *     {@link Workflow }
     *     
     */
    public void setWorkflow(Workflow value) {
        this.workflow = value;
    }

    /**
     * Gets the value of the amendments property.
     * 
     * @return
     *     possible object is
     *     {@link Amendments }
     *     
     */
    public Amendments getAmendments() {
        return amendments;
    }

    /**
     * Sets the value of the amendments property.
     * 
     * @param value
     *     allowed object is
     *     {@link Amendments }
     *     
     */
    public void setAmendments(Amendments value) {
        this.amendments = value;
    }

    /**
     * Gets the value of the answers property.
     * 
     * @return
     *     possible object is
     *     {@link Answers }
     *     
     */
    public Answers getAnswers() {
        return answers;
    }

    /**
     * Sets the value of the answers property.
     * 
     * @param value
     *     allowed object is
     *     {@link Answers }
     *     
     */
    public void setAnswers(Answers value) {
        this.answers = value;
    }

}
