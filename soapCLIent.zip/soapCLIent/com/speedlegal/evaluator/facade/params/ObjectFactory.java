
package com.speedlegal.evaluator.facade.params;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.speedlegal.evaluator.facade.params package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.speedlegal.evaluator.facade.params
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link BatchRequest }
     * 
     */
    public BatchRequest createBatchRequest() {
        return new BatchRequest();
    }

    /**
     * Create an instance of {@link BatchOutputResult }
     * 
     */
    public BatchOutputResult createBatchOutputResult() {
        return new BatchOutputResult();
    }

    /**
     * Create an instance of {@link BatchResponse }
     * 
     */
    public BatchResponse createBatchResponse() {
        return new BatchResponse();
    }

    /**
     * Create an instance of {@link DescribeResponse }
     * 
     */
    public DescribeResponse createDescribeResponse() {
        return new DescribeResponse();
    }

    /**
     * Create an instance of {@link DataType }
     * 
     */
    public DataType createDataType() {
        return new DataType();
    }

    /**
     * Create an instance of {@link BatchRequest.CoreEvaluation }
     * 
     */
    public BatchRequest.CoreEvaluation createBatchRequestCoreEvaluation() {
        return new BatchRequest.CoreEvaluation();
    }

    /**
     * Create an instance of {@link BatchRequest.BatchEvaluation }
     * 
     */
    public BatchRequest.BatchEvaluation createBatchRequestBatchEvaluation() {
        return new BatchRequest.BatchEvaluation();
    }

    /**
     * Create an instance of {@link GeneratedDocument }
     * 
     */
    public GeneratedDocument createGeneratedDocument() {
        return new GeneratedDocument();
    }

    /**
     * Create an instance of {@link BatchOutputResult.GenerationFault }
     * 
     */
    public BatchOutputResult.GenerationFault createBatchOutputResultGenerationFault() {
        return new BatchOutputResult.GenerationFault();
    }

    /**
     * Create an instance of {@link Answers }
     * 
     */
    public Answers createAnswers() {
        return new Answers();
    }

    /**
     * Create an instance of {@link InterviewPreferences }
     * 
     */
    public InterviewPreferences createInterviewPreferences() {
        return new InterviewPreferences();
    }

    /**
     * Create an instance of {@link BatchResponse.BatchEvaluationResult }
     * 
     */
    public BatchResponse.BatchEvaluationResult createBatchResponseBatchEvaluationResult() {
        return new BatchResponse.BatchEvaluationResult();
    }

    /**
     * Create an instance of {@link EvaluationResponse }
     * 
     */
    public EvaluationResponse createEvaluationResponse() {
        return new EvaluationResponse();
    }

    /**
     * Create an instance of {@link RenderedDataSource }
     * 
     */
    public RenderedDataSource createRenderedDataSource() {
        return new RenderedDataSource();
    }

    /**
     * Create an instance of {@link UnAnsweredQuestions }
     * 
     */
    public UnAnsweredQuestions createUnAnsweredQuestions() {
        return new UnAnsweredQuestions();
    }

    /**
     * Create an instance of {@link AnsweredQuestions }
     * 
     */
    public AnsweredQuestions createAnsweredQuestions() {
        return new AnsweredQuestions();
    }

    /**
     * Create an instance of {@link LogicItem }
     * 
     */
    public LogicItem createLogicItem() {
        return new LogicItem();
    }

    /**
     * Create an instance of {@link RenderRequest }
     * 
     */
    public RenderRequest createRenderRequest() {
        return new RenderRequest();
    }

    /**
     * Create an instance of {@link Document }
     * 
     */
    public Document createDocument() {
        return new Document();
    }

    /**
     * Create an instance of {@link FeatureSet }
     * 
     */
    public FeatureSet createFeatureSet() {
        return new FeatureSet();
    }

    /**
     * Create an instance of {@link EvaluationRequest }
     * 
     */
    public EvaluationRequest createEvaluationRequest() {
        return new EvaluationRequest();
    }

    /**
     * Create an instance of {@link References }
     * 
     */
    public References createReferences() {
        return new References();
    }

    /**
     * Create an instance of {@link Reference }
     * 
     */
    public Reference createReference() {
        return new Reference();
    }

    /**
     * Create an instance of {@link DescribeResponse.LogicItems }
     * 
     */
    public DescribeResponse.LogicItems createDescribeResponseLogicItems() {
        return new DescribeResponse.LogicItems();
    }

    /**
     * Create an instance of {@link DescribeResponse.DataTypes }
     * 
     */
    public DescribeResponse.DataTypes createDescribeResponseDataTypes() {
        return new DescribeResponse.DataTypes();
    }

    /**
     * Create an instance of {@link DataType.Annotation }
     * 
     */
    public DataType.Annotation createDataTypeAnnotation() {
        return new DataType.Annotation();
    }

    /**
     * Create an instance of {@link DescribePreferences }
     * 
     */
    public DescribePreferences createDescribePreferences() {
        return new DescribePreferences();
    }

    /**
     * Create an instance of {@link DescribeRequest }
     * 
     */
    public DescribeRequest createDescribeRequest() {
        return new DescribeRequest();
    }

    /**
     * Create an instance of {@link RenderResponse }
     * 
     */
    public RenderResponse createRenderResponse() {
        return new RenderResponse();
    }

    /**
     * Create an instance of {@link BatchRequest.CoreEvaluation.CoreAnswers }
     * 
     */
    public BatchRequest.CoreEvaluation.CoreAnswers createBatchRequestCoreEvaluationCoreAnswers() {
        return new BatchRequest.CoreEvaluation.CoreAnswers();
    }

}
