
package com.speedlegal.evaluator.facade.params;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.speedlegal.common.xml.Amendments;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://speedlegal.com/evaluator/facade/params}RenderedDataSource" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://speedlegal.com/evaluator/facade/params}UnAnsweredQuestions" minOccurs="0"/>
 *         &lt;element ref="{http://speedlegal.com/common/xml}Amendments" minOccurs="0"/>
 *         &lt;element ref="{http://speedlegal.com/evaluator/facade/params}AnsweredQuestions" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "renderedDataSource",
    "unAnsweredQuestions",
    "amendments",
    "answeredQuestions"
})
@XmlRootElement(name = "EvaluationResponse")
public class EvaluationResponse {

    @XmlElement(name = "RenderedDataSource")
    protected List<RenderedDataSource> renderedDataSource;
    @XmlElement(name = "UnAnsweredQuestions")
    protected UnAnsweredQuestions unAnsweredQuestions;
    @XmlElement(name = "Amendments", namespace = "http://speedlegal.com/common/xml")
    protected Amendments amendments;
    @XmlElement(name = "AnsweredQuestions")
    protected AnsweredQuestions answeredQuestions;

    /**
     * Gets the value of the renderedDataSource property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the renderedDataSource property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRenderedDataSource().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RenderedDataSource }
     * 
     * 
     */
    public List<RenderedDataSource> getRenderedDataSource() {
        if (renderedDataSource == null) {
            renderedDataSource = new ArrayList<RenderedDataSource>();
        }
        return this.renderedDataSource;
    }

    /**
     * Gets the value of the unAnsweredQuestions property.
     * 
     * @return
     *     possible object is
     *     {@link UnAnsweredQuestions }
     *     
     */
    public UnAnsweredQuestions getUnAnsweredQuestions() {
        return unAnsweredQuestions;
    }

    /**
     * Sets the value of the unAnsweredQuestions property.
     * 
     * @param value
     *     allowed object is
     *     {@link UnAnsweredQuestions }
     *     
     */
    public void setUnAnsweredQuestions(UnAnsweredQuestions value) {
        this.unAnsweredQuestions = value;
    }

    /**
     * Gets the value of the amendments property.
     * 
     * @return
     *     possible object is
     *     {@link Amendments }
     *     
     */
    public Amendments getAmendments() {
        return amendments;
    }

    /**
     * Sets the value of the amendments property.
     * 
     * @param value
     *     allowed object is
     *     {@link Amendments }
     *     
     */
    public void setAmendments(Amendments value) {
        this.amendments = value;
    }

    /**
     * Gets the value of the answeredQuestions property.
     * 
     * @return
     *     possible object is
     *     {@link AnsweredQuestions }
     *     
     */
    public AnsweredQuestions getAnsweredQuestions() {
        return answeredQuestions;
    }

    /**
     * Sets the value of the answeredQuestions property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnsweredQuestions }
     *     
     */
    public void setAnsweredQuestions(AnsweredQuestions value) {
        this.answeredQuestions = value;
    }

}
