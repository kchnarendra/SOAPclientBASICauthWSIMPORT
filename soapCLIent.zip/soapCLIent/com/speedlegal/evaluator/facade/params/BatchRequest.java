
package com.speedlegal.evaluator.facade.params;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.speedlegal.common.xml.AnswerMap;
import com.speedlegal.common.xml.OutputPreferences;
import com.speedlegal.common.xml.Response;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CoreEvaluation">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element ref="{http://speedlegal.com/evaluator/facade/params}Document"/>
 *                   &lt;element ref="{http://speedlegal.com/evaluator/facade/params}InterviewPreferences" minOccurs="0"/>
 *                   &lt;element ref="{http://speedlegal.com/common/xml}OutputPreferences" minOccurs="0"/>
 *                   &lt;element name="CoreAnswers" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element ref="{http://speedlegal.com/common/xml}Response" maxOccurs="unbounded" minOccurs="0"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="BatchEvaluation" maxOccurs="unbounded">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="BatchAnswers" type="{http://speedlegal.com/common/xml}AnswerMap" minOccurs="0"/>
 *                   &lt;element ref="{http://speedlegal.com/common/xml}OutputPreferences" maxOccurs="unbounded" minOccurs="0"/>
 *                   &lt;element name="OutputFormat" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "coreEvaluation",
    "batchEvaluation"
})
@XmlRootElement(name = "BatchRequest")
public class BatchRequest {

    @XmlElement(name = "CoreEvaluation", required = true)
    protected BatchRequest.CoreEvaluation coreEvaluation;
    @XmlElement(name = "BatchEvaluation", required = true)
    protected List<BatchRequest.BatchEvaluation> batchEvaluation;

    /**
     * Gets the value of the coreEvaluation property.
     * 
     * @return
     *     possible object is
     *     {@link BatchRequest.CoreEvaluation }
     *     
     */
    public BatchRequest.CoreEvaluation getCoreEvaluation() {
        return coreEvaluation;
    }

    /**
     * Sets the value of the coreEvaluation property.
     * 
     * @param value
     *     allowed object is
     *     {@link BatchRequest.CoreEvaluation }
     *     
     */
    public void setCoreEvaluation(BatchRequest.CoreEvaluation value) {
        this.coreEvaluation = value;
    }

    /**
     * Gets the value of the batchEvaluation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the batchEvaluation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBatchEvaluation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BatchRequest.BatchEvaluation }
     * 
     * 
     */
    public List<BatchRequest.BatchEvaluation> getBatchEvaluation() {
        if (batchEvaluation == null) {
            batchEvaluation = new ArrayList<BatchRequest.BatchEvaluation>();
        }
        return this.batchEvaluation;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="BatchAnswers" type="{http://speedlegal.com/common/xml}AnswerMap" minOccurs="0"/>
     *         &lt;element ref="{http://speedlegal.com/common/xml}OutputPreferences" maxOccurs="unbounded" minOccurs="0"/>
     *         &lt;element name="OutputFormat" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}ID" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "batchAnswers",
        "outputPreferences",
        "outputFormat"
    })
    public static class BatchEvaluation {

        @XmlElement(name = "BatchAnswers")
        protected AnswerMap batchAnswers;
        @XmlElement(name = "OutputPreferences", namespace = "http://speedlegal.com/common/xml")
        protected List<OutputPreferences> outputPreferences;
        @XmlElement(name = "OutputFormat")
        protected List<String> outputFormat;
        @XmlAttribute(name = "id")
        @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
        @XmlID
        @XmlSchemaType(name = "ID")
        protected String id;

        /**
         * Gets the value of the batchAnswers property.
         * 
         * @return
         *     possible object is
         *     {@link AnswerMap }
         *     
         */
        public AnswerMap getBatchAnswers() {
            return batchAnswers;
        }

        /**
         * Sets the value of the batchAnswers property.
         * 
         * @param value
         *     allowed object is
         *     {@link AnswerMap }
         *     
         */
        public void setBatchAnswers(AnswerMap value) {
            this.batchAnswers = value;
        }

        /**
         * Gets the value of the outputPreferences property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the outputPreferences property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getOutputPreferences().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link OutputPreferences }
         * 
         * 
         */
        public List<OutputPreferences> getOutputPreferences() {
            if (outputPreferences == null) {
                outputPreferences = new ArrayList<OutputPreferences>();
            }
            return this.outputPreferences;
        }

        /**
         * Gets the value of the outputFormat property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the outputFormat property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getOutputFormat().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getOutputFormat() {
            if (outputFormat == null) {
                outputFormat = new ArrayList<String>();
            }
            return this.outputFormat;
        }

        /**
         * Gets the value of the id property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getId() {
            return id;
        }

        /**
         * Sets the value of the id property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setId(String value) {
            this.id = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element ref="{http://speedlegal.com/evaluator/facade/params}Document"/>
     *         &lt;element ref="{http://speedlegal.com/evaluator/facade/params}InterviewPreferences" minOccurs="0"/>
     *         &lt;element ref="{http://speedlegal.com/common/xml}OutputPreferences" minOccurs="0"/>
     *         &lt;element name="CoreAnswers" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element ref="{http://speedlegal.com/common/xml}Response" maxOccurs="unbounded" minOccurs="0"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "document",
        "interviewPreferences",
        "outputPreferences",
        "coreAnswers"
    })
    public static class CoreEvaluation {

        @XmlElement(name = "Document", required = true)
        protected Document document;
        @XmlElement(name = "InterviewPreferences")
        protected InterviewPreferences interviewPreferences;
        @XmlElement(name = "OutputPreferences", namespace = "http://speedlegal.com/common/xml")
        protected OutputPreferences outputPreferences;
        @XmlElement(name = "CoreAnswers")
        protected BatchRequest.CoreEvaluation.CoreAnswers coreAnswers;

        /**
         * Gets the value of the document property.
         * 
         * @return
         *     possible object is
         *     {@link Document }
         *     
         */
        public Document getDocument() {
            return document;
        }

        /**
         * Sets the value of the document property.
         * 
         * @param value
         *     allowed object is
         *     {@link Document }
         *     
         */
        public void setDocument(Document value) {
            this.document = value;
        }

        /**
         * Gets the value of the interviewPreferences property.
         * 
         * @return
         *     possible object is
         *     {@link InterviewPreferences }
         *     
         */
        public InterviewPreferences getInterviewPreferences() {
            return interviewPreferences;
        }

        /**
         * Sets the value of the interviewPreferences property.
         * 
         * @param value
         *     allowed object is
         *     {@link InterviewPreferences }
         *     
         */
        public void setInterviewPreferences(InterviewPreferences value) {
            this.interviewPreferences = value;
        }

        /**
         * Gets the value of the outputPreferences property.
         * 
         * @return
         *     possible object is
         *     {@link OutputPreferences }
         *     
         */
        public OutputPreferences getOutputPreferences() {
            return outputPreferences;
        }

        /**
         * Sets the value of the outputPreferences property.
         * 
         * @param value
         *     allowed object is
         *     {@link OutputPreferences }
         *     
         */
        public void setOutputPreferences(OutputPreferences value) {
            this.outputPreferences = value;
        }

        /**
         * Gets the value of the coreAnswers property.
         * 
         * @return
         *     possible object is
         *     {@link BatchRequest.CoreEvaluation.CoreAnswers }
         *     
         */
        public BatchRequest.CoreEvaluation.CoreAnswers getCoreAnswers() {
            return coreAnswers;
        }

        /**
         * Sets the value of the coreAnswers property.
         * 
         * @param value
         *     allowed object is
         *     {@link BatchRequest.CoreEvaluation.CoreAnswers }
         *     
         */
        public void setCoreAnswers(BatchRequest.CoreEvaluation.CoreAnswers value) {
            this.coreAnswers = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element ref="{http://speedlegal.com/common/xml}Response" maxOccurs="unbounded" minOccurs="0"/>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "response"
        })
        public static class CoreAnswers {

            @XmlElement(name = "Response", namespace = "http://speedlegal.com/common/xml")
            protected List<Response> response;

            /**
             * Gets the value of the response property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the response property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getResponse().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link Response }
             * 
             * 
             */
            public List<Response> getResponse() {
                if (response == null) {
                    response = new ArrayList<Response>();
                }
                return this.response;
            }

        }

    }

}
