
package com.speedlegal.evaluator.facade.params;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Bias" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Style" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FastForward" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ShowVariableNames" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="RegisterUsage" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="AllowSessionLoading" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="CreateSessionToken" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Title" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "bias",
    "style",
    "fastForward",
    "showVariableNames",
    "registerUsage",
    "allowSessionLoading",
    "createSessionToken",
    "title"
})
@XmlRootElement(name = "InterviewPreferences")
public class InterviewPreferences {

    @XmlElement(name = "Bias", defaultValue = "neutral")
    protected String bias;
    @XmlElement(name = "Style")
    protected String style;
    @XmlElement(name = "FastForward", defaultValue = "false")
    protected Boolean fastForward;
    @XmlElement(name = "ShowVariableNames", defaultValue = "false")
    protected Boolean showVariableNames;
    @XmlElement(name = "RegisterUsage", defaultValue = "true")
    protected Boolean registerUsage;
    @XmlElement(name = "AllowSessionLoading", defaultValue = "false")
    protected Boolean allowSessionLoading;
    @XmlElement(name = "CreateSessionToken", defaultValue = "false")
    protected Boolean createSessionToken;
    @XmlElement(name = "Title", defaultValue = "")
    protected String title;

    /**
     * Gets the value of the bias property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBias() {
        return bias;
    }

    /**
     * Sets the value of the bias property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBias(String value) {
        this.bias = value;
    }

    /**
     * Gets the value of the style property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStyle() {
        return style;
    }

    /**
     * Sets the value of the style property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStyle(String value) {
        this.style = value;
    }

    /**
     * Gets the value of the fastForward property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isFastForward() {
        return fastForward;
    }

    /**
     * Sets the value of the fastForward property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setFastForward(Boolean value) {
        this.fastForward = value;
    }

    /**
     * Gets the value of the showVariableNames property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isShowVariableNames() {
        return showVariableNames;
    }

    /**
     * Sets the value of the showVariableNames property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setShowVariableNames(Boolean value) {
        this.showVariableNames = value;
    }

    /**
     * Gets the value of the registerUsage property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRegisterUsage() {
        return registerUsage;
    }

    /**
     * Sets the value of the registerUsage property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRegisterUsage(Boolean value) {
        this.registerUsage = value;
    }

    /**
     * Gets the value of the allowSessionLoading property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isAllowSessionLoading() {
        return allowSessionLoading;
    }

    /**
     * Sets the value of the allowSessionLoading property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAllowSessionLoading(Boolean value) {
        this.allowSessionLoading = value;
    }

    /**
     * Gets the value of the createSessionToken property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCreateSessionToken() {
        return createSessionToken;
    }

    /**
     * Sets the value of the createSessionToken property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCreateSessionToken(Boolean value) {
        this.createSessionToken = value;
    }

    /**
     * Gets the value of the title property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the value of the title property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTitle(String value) {
        this.title = value;
    }

}
