
package com.speedlegal.common.xml;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Java class for InsertableUsage complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="InsertableUsage">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="delta" maxOccurs="unbounded" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                 &lt;/sequence>
 *                 &lt;attribute name="delta_id" type="{http://www.w3.org/2001/XMLSchema}string" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *       &lt;attribute name="xpath" use="required" type="{http://www.w3.org/2001/XMLSchema}NMTOKEN" />
 *       &lt;attribute name="Inline" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="posLeading" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="charLeading" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="posTrailing" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="charTrailing" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="title" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InsertableUsage", propOrder = {
    "delta"
})
public class InsertableUsage {

    @XmlElement(nillable = true)
    protected List<InsertableUsage.Delta> delta;
    @XmlAttribute(name = "xpath", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NMTOKEN")
    protected String xpath;
    @XmlAttribute(name = "Inline", required = true)
    protected int inline;
    @XmlAttribute(name = "posLeading")
    protected Integer posLeading;
    @XmlAttribute(name = "charLeading")
    protected Integer charLeading;
    @XmlAttribute(name = "posTrailing")
    protected Integer posTrailing;
    @XmlAttribute(name = "charTrailing")
    protected Integer charTrailing;
    @XmlAttribute(name = "title")
    protected String title;

    /**
     * Gets the value of the delta property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the delta property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDelta().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InsertableUsage.Delta }
     * 
     * 
     */
    public List<InsertableUsage.Delta> getDelta() {
        if (delta == null) {
            delta = new ArrayList<InsertableUsage.Delta>();
        }
        return this.delta;
    }

    /**
     * Gets the value of the xpath property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getXpath() {
        return xpath;
    }

    /**
     * Sets the value of the xpath property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setXpath(String value) {
        this.xpath = value;
    }

    /**
     * Gets the value of the inline property.
     * 
     */
    public int getInline() {
        return inline;
    }

    /**
     * Sets the value of the inline property.
     * 
     */
    public void setInline(int value) {
        this.inline = value;
    }

    /**
     * Gets the value of the posLeading property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPosLeading() {
        return posLeading;
    }

    /**
     * Sets the value of the posLeading property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPosLeading(Integer value) {
        this.posLeading = value;
    }

    /**
     * Gets the value of the charLeading property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCharLeading() {
        return charLeading;
    }

    /**
     * Sets the value of the charLeading property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCharLeading(Integer value) {
        this.charLeading = value;
    }

    /**
     * Gets the value of the posTrailing property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPosTrailing() {
        return posTrailing;
    }

    /**
     * Sets the value of the posTrailing property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPosTrailing(Integer value) {
        this.posTrailing = value;
    }

    /**
     * Gets the value of the charTrailing property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCharTrailing() {
        return charTrailing;
    }

    /**
     * Sets the value of the charTrailing property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCharTrailing(Integer value) {
        this.charTrailing = value;
    }

    /**
     * Gets the value of the title property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the value of the title property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTitle(String value) {
        this.title = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *       &lt;/sequence>
     *       &lt;attribute name="delta_id" type="{http://www.w3.org/2001/XMLSchema}string" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class Delta {

        @XmlAttribute(name = "delta_id")
        protected String deltaId;

        /**
         * Gets the value of the deltaId property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDeltaId() {
            return deltaId;
        }

        /**
         * Sets the value of the deltaId property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDeltaId(String value) {
            this.deltaId = value;
        }

    }

}
