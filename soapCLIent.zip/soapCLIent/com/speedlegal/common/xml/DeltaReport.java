
package com.speedlegal.common.xml;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://speedlegal.com/common/xml}TextChange" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://speedlegal.com/common/xml}ValueChange" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "textChange",
    "valueChange"
})
@XmlRootElement(name = "DeltaReport")
public class DeltaReport {

    @XmlElement(name = "TextChange")
    protected List<TextChange> textChange;
    @XmlElement(name = "ValueChange")
    protected List<ValueChange> valueChange;

    /**
     * Gets the value of the textChange property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the textChange property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTextChange().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TextChange }
     * 
     * 
     */
    public List<TextChange> getTextChange() {
        if (textChange == null) {
            textChange = new ArrayList<TextChange>();
        }
        return this.textChange;
    }

    /**
     * Gets the value of the valueChange property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the valueChange property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getValueChange().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ValueChange }
     * 
     * 
     */
    public List<ValueChange> getValueChange() {
        if (valueChange == null) {
            valueChange = new ArrayList<ValueChange>();
        }
        return this.valueChange;
    }

}
