
package com.speedlegal.common.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DocumentDetails" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Publish" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
 *                   &lt;element name="Delete" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
 *                   &lt;element name="EditProperties" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
 *                   &lt;element name="CreateShortcut" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ResourceMigration" type="{http://speedlegal.com/common/xml}ResourceMigrationWorkflow" minOccurs="0"/>
 *         &lt;element name="InterviewPrepare" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="TemplateLoad" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
 *                   &lt;element name="LogicLoad" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="InterviewRound" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Next" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
 *                   &lt;element name="Complete" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="AnswerManagement" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Save" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
 *                   &lt;element name="Load" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
 *                   &lt;element name="DeltaSave" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ActiveTextPreview" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Done" type="{http://speedlegal.com/common/xml}Action"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="OutputOptions">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Finish" type="{http://speedlegal.com/common/xml}Action"/>
 *                   &lt;element ref="{http://speedlegal.com/common/xml}OutputPreferences" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="InterviewCommon" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Quit" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "documentDetails",
    "resourceMigration",
    "interviewPrepare",
    "interviewRound",
    "answerManagement",
    "activeTextPreview",
    "outputOptions",
    "interviewCommon"
})
@XmlRootElement(name = "Workflow")
public class Workflow {

    @XmlElement(name = "DocumentDetails")
    protected Workflow.DocumentDetails documentDetails;
    @XmlElement(name = "ResourceMigration")
    protected ResourceMigrationWorkflow resourceMigration;
    @XmlElement(name = "InterviewPrepare")
    protected Workflow.InterviewPrepare interviewPrepare;
    @XmlElement(name = "InterviewRound")
    protected Workflow.InterviewRound interviewRound;
    @XmlElement(name = "AnswerManagement")
    protected Workflow.AnswerManagement answerManagement;
    @XmlElement(name = "ActiveTextPreview")
    protected Workflow.ActiveTextPreview activeTextPreview;
    @XmlElement(name = "OutputOptions", required = true)
    protected Workflow.OutputOptions outputOptions;
    @XmlElement(name = "InterviewCommon")
    protected Workflow.InterviewCommon interviewCommon;

    /**
     * Gets the value of the documentDetails property.
     * 
     * @return
     *     possible object is
     *     {@link Workflow.DocumentDetails }
     *     
     */
    public Workflow.DocumentDetails getDocumentDetails() {
        return documentDetails;
    }

    /**
     * Sets the value of the documentDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link Workflow.DocumentDetails }
     *     
     */
    public void setDocumentDetails(Workflow.DocumentDetails value) {
        this.documentDetails = value;
    }

    /**
     * Gets the value of the resourceMigration property.
     * 
     * @return
     *     possible object is
     *     {@link ResourceMigrationWorkflow }
     *     
     */
    public ResourceMigrationWorkflow getResourceMigration() {
        return resourceMigration;
    }

    /**
     * Sets the value of the resourceMigration property.
     * 
     * @param value
     *     allowed object is
     *     {@link ResourceMigrationWorkflow }
     *     
     */
    public void setResourceMigration(ResourceMigrationWorkflow value) {
        this.resourceMigration = value;
    }

    /**
     * Gets the value of the interviewPrepare property.
     * 
     * @return
     *     possible object is
     *     {@link Workflow.InterviewPrepare }
     *     
     */
    public Workflow.InterviewPrepare getInterviewPrepare() {
        return interviewPrepare;
    }

    /**
     * Sets the value of the interviewPrepare property.
     * 
     * @param value
     *     allowed object is
     *     {@link Workflow.InterviewPrepare }
     *     
     */
    public void setInterviewPrepare(Workflow.InterviewPrepare value) {
        this.interviewPrepare = value;
    }

    /**
     * Gets the value of the interviewRound property.
     * 
     * @return
     *     possible object is
     *     {@link Workflow.InterviewRound }
     *     
     */
    public Workflow.InterviewRound getInterviewRound() {
        return interviewRound;
    }

    /**
     * Sets the value of the interviewRound property.
     * 
     * @param value
     *     allowed object is
     *     {@link Workflow.InterviewRound }
     *     
     */
    public void setInterviewRound(Workflow.InterviewRound value) {
        this.interviewRound = value;
    }

    /**
     * Gets the value of the answerManagement property.
     * 
     * @return
     *     possible object is
     *     {@link Workflow.AnswerManagement }
     *     
     */
    public Workflow.AnswerManagement getAnswerManagement() {
        return answerManagement;
    }

    /**
     * Sets the value of the answerManagement property.
     * 
     * @param value
     *     allowed object is
     *     {@link Workflow.AnswerManagement }
     *     
     */
    public void setAnswerManagement(Workflow.AnswerManagement value) {
        this.answerManagement = value;
    }

    /**
     * Gets the value of the activeTextPreview property.
     * 
     * @return
     *     possible object is
     *     {@link Workflow.ActiveTextPreview }
     *     
     */
    public Workflow.ActiveTextPreview getActiveTextPreview() {
        return activeTextPreview;
    }

    /**
     * Sets the value of the activeTextPreview property.
     * 
     * @param value
     *     allowed object is
     *     {@link Workflow.ActiveTextPreview }
     *     
     */
    public void setActiveTextPreview(Workflow.ActiveTextPreview value) {
        this.activeTextPreview = value;
    }

    /**
     * Gets the value of the outputOptions property.
     * 
     * @return
     *     possible object is
     *     {@link Workflow.OutputOptions }
     *     
     */
    public Workflow.OutputOptions getOutputOptions() {
        return outputOptions;
    }

    /**
     * Sets the value of the outputOptions property.
     * 
     * @param value
     *     allowed object is
     *     {@link Workflow.OutputOptions }
     *     
     */
    public void setOutputOptions(Workflow.OutputOptions value) {
        this.outputOptions = value;
    }

    /**
     * Gets the value of the interviewCommon property.
     * 
     * @return
     *     possible object is
     *     {@link Workflow.InterviewCommon }
     *     
     */
    public Workflow.InterviewCommon getInterviewCommon() {
        return interviewCommon;
    }

    /**
     * Sets the value of the interviewCommon property.
     * 
     * @param value
     *     allowed object is
     *     {@link Workflow.InterviewCommon }
     *     
     */
    public void setInterviewCommon(Workflow.InterviewCommon value) {
        this.interviewCommon = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Done" type="{http://speedlegal.com/common/xml}Action"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "done"
    })
    public static class ActiveTextPreview {

        @XmlElement(name = "Done", required = true)
        protected Action done;

        /**
         * Gets the value of the done property.
         * 
         * @return
         *     possible object is
         *     {@link Action }
         *     
         */
        public Action getDone() {
            return done;
        }

        /**
         * Sets the value of the done property.
         * 
         * @param value
         *     allowed object is
         *     {@link Action }
         *     
         */
        public void setDone(Action value) {
            this.done = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Save" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
     *         &lt;element name="Load" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
     *         &lt;element name="DeltaSave" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "save",
        "load",
        "deltaSave"
    })
    public static class AnswerManagement {

        @XmlElement(name = "Save")
        protected Action save;
        @XmlElement(name = "Load")
        protected Action load;
        @XmlElement(name = "DeltaSave")
        protected Action deltaSave;

        /**
         * Gets the value of the save property.
         * 
         * @return
         *     possible object is
         *     {@link Action }
         *     
         */
        public Action getSave() {
            return save;
        }

        /**
         * Sets the value of the save property.
         * 
         * @param value
         *     allowed object is
         *     {@link Action }
         *     
         */
        public void setSave(Action value) {
            this.save = value;
        }

        /**
         * Gets the value of the load property.
         * 
         * @return
         *     possible object is
         *     {@link Action }
         *     
         */
        public Action getLoad() {
            return load;
        }

        /**
         * Sets the value of the load property.
         * 
         * @param value
         *     allowed object is
         *     {@link Action }
         *     
         */
        public void setLoad(Action value) {
            this.load = value;
        }

        /**
         * Gets the value of the deltaSave property.
         * 
         * @return
         *     possible object is
         *     {@link Action }
         *     
         */
        public Action getDeltaSave() {
            return deltaSave;
        }

        /**
         * Sets the value of the deltaSave property.
         * 
         * @param value
         *     allowed object is
         *     {@link Action }
         *     
         */
        public void setDeltaSave(Action value) {
            this.deltaSave = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Publish" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
     *         &lt;element name="Delete" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
     *         &lt;element name="EditProperties" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
     *         &lt;element name="CreateShortcut" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "publish",
        "delete",
        "editProperties",
        "createShortcut"
    })
    public static class DocumentDetails {

        @XmlElement(name = "Publish")
        protected Action publish;
        @XmlElement(name = "Delete")
        protected Action delete;
        @XmlElement(name = "EditProperties")
        protected Action editProperties;
        @XmlElement(name = "CreateShortcut")
        protected Action createShortcut;

        /**
         * Gets the value of the publish property.
         * 
         * @return
         *     possible object is
         *     {@link Action }
         *     
         */
        public Action getPublish() {
            return publish;
        }

        /**
         * Sets the value of the publish property.
         * 
         * @param value
         *     allowed object is
         *     {@link Action }
         *     
         */
        public void setPublish(Action value) {
            this.publish = value;
        }

        /**
         * Gets the value of the delete property.
         * 
         * @return
         *     possible object is
         *     {@link Action }
         *     
         */
        public Action getDelete() {
            return delete;
        }

        /**
         * Sets the value of the delete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Action }
         *     
         */
        public void setDelete(Action value) {
            this.delete = value;
        }

        /**
         * Gets the value of the editProperties property.
         * 
         * @return
         *     possible object is
         *     {@link Action }
         *     
         */
        public Action getEditProperties() {
            return editProperties;
        }

        /**
         * Sets the value of the editProperties property.
         * 
         * @param value
         *     allowed object is
         *     {@link Action }
         *     
         */
        public void setEditProperties(Action value) {
            this.editProperties = value;
        }

        /**
         * Gets the value of the createShortcut property.
         * 
         * @return
         *     possible object is
         *     {@link Action }
         *     
         */
        public Action getCreateShortcut() {
            return createShortcut;
        }

        /**
         * Sets the value of the createShortcut property.
         * 
         * @param value
         *     allowed object is
         *     {@link Action }
         *     
         */
        public void setCreateShortcut(Action value) {
            this.createShortcut = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Quit" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "quit"
    })
    public static class InterviewCommon {

        @XmlElement(name = "Quit")
        protected Action quit;

        /**
         * Gets the value of the quit property.
         * 
         * @return
         *     possible object is
         *     {@link Action }
         *     
         */
        public Action getQuit() {
            return quit;
        }

        /**
         * Sets the value of the quit property.
         * 
         * @param value
         *     allowed object is
         *     {@link Action }
         *     
         */
        public void setQuit(Action value) {
            this.quit = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="TemplateLoad" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
     *         &lt;element name="LogicLoad" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "templateLoad",
        "logicLoad"
    })
    public static class InterviewPrepare {

        @XmlElement(name = "TemplateLoad")
        protected Action templateLoad;
        @XmlElement(name = "LogicLoad")
        protected Action logicLoad;

        /**
         * Gets the value of the templateLoad property.
         * 
         * @return
         *     possible object is
         *     {@link Action }
         *     
         */
        public Action getTemplateLoad() {
            return templateLoad;
        }

        /**
         * Sets the value of the templateLoad property.
         * 
         * @param value
         *     allowed object is
         *     {@link Action }
         *     
         */
        public void setTemplateLoad(Action value) {
            this.templateLoad = value;
        }

        /**
         * Gets the value of the logicLoad property.
         * 
         * @return
         *     possible object is
         *     {@link Action }
         *     
         */
        public Action getLogicLoad() {
            return logicLoad;
        }

        /**
         * Sets the value of the logicLoad property.
         * 
         * @param value
         *     allowed object is
         *     {@link Action }
         *     
         */
        public void setLogicLoad(Action value) {
            this.logicLoad = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Next" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
     *         &lt;element name="Complete" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "next",
        "complete"
    })
    public static class InterviewRound {

        @XmlElement(name = "Next")
        protected Action next;
        @XmlElement(name = "Complete")
        protected Action complete;

        /**
         * Gets the value of the next property.
         * 
         * @return
         *     possible object is
         *     {@link Action }
         *     
         */
        public Action getNext() {
            return next;
        }

        /**
         * Sets the value of the next property.
         * 
         * @param value
         *     allowed object is
         *     {@link Action }
         *     
         */
        public void setNext(Action value) {
            this.next = value;
        }

        /**
         * Gets the value of the complete property.
         * 
         * @return
         *     possible object is
         *     {@link Action }
         *     
         */
        public Action getComplete() {
            return complete;
        }

        /**
         * Sets the value of the complete property.
         * 
         * @param value
         *     allowed object is
         *     {@link Action }
         *     
         */
        public void setComplete(Action value) {
            this.complete = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Finish" type="{http://speedlegal.com/common/xml}Action"/>
     *         &lt;element ref="{http://speedlegal.com/common/xml}OutputPreferences" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "finish",
        "outputPreferences"
    })
    public static class OutputOptions {

        @XmlElement(name = "Finish", required = true)
        protected Action finish;
        @XmlElement(name = "OutputPreferences")
        protected OutputPreferences outputPreferences;

        /**
         * Gets the value of the finish property.
         * 
         * @return
         *     possible object is
         *     {@link Action }
         *     
         */
        public Action getFinish() {
            return finish;
        }

        /**
         * Sets the value of the finish property.
         * 
         * @param value
         *     allowed object is
         *     {@link Action }
         *     
         */
        public void setFinish(Action value) {
            this.finish = value;
        }

        /**
         * Gets the value of the outputPreferences property.
         * 
         * @return
         *     possible object is
         *     {@link OutputPreferences }
         *     
         */
        public OutputPreferences getOutputPreferences() {
            return outputPreferences;
        }

        /**
         * Sets the value of the outputPreferences property.
         * 
         * @param value
         *     allowed object is
         *     {@link OutputPreferences }
         *     
         */
        public void setOutputPreferences(OutputPreferences value) {
            this.outputPreferences = value;
        }

    }

}
