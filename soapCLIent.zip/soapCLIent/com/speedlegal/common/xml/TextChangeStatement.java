
package com.speedlegal.common.xml;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TextChangeStatement complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TextChangeStatement">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="OldText" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NewText" type="{http://speedlegal.com/common/xml}StringWithChanges"/>
 *         &lt;element name="delta" maxOccurs="unbounded" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                 &lt;/sequence>
 *                 &lt;attribute name="delta_id" type="{http://www.w3.org/2001/XMLSchema}string" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TextChangeStatement", propOrder = {
    "oldText",
    "newText",
    "delta"
})
public class TextChangeStatement {

    @XmlElement(name = "OldText")
    protected String oldText;
    @XmlElement(name = "NewText", required = true)
    protected StringWithChanges newText;
    @XmlElement(nillable = true)
    protected List<TextChangeStatement.Delta> delta;

    /**
     * Gets the value of the oldText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOldText() {
        return oldText;
    }

    /**
     * Sets the value of the oldText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOldText(String value) {
        this.oldText = value;
    }

    /**
     * Gets the value of the newText property.
     * 
     * @return
     *     possible object is
     *     {@link StringWithChanges }
     *     
     */
    public StringWithChanges getNewText() {
        return newText;
    }

    /**
     * Sets the value of the newText property.
     * 
     * @param value
     *     allowed object is
     *     {@link StringWithChanges }
     *     
     */
    public void setNewText(StringWithChanges value) {
        this.newText = value;
    }

    /**
     * Gets the value of the delta property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the delta property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDelta().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TextChangeStatement.Delta }
     * 
     * 
     */
    public List<TextChangeStatement.Delta> getDelta() {
        if (delta == null) {
            delta = new ArrayList<TextChangeStatement.Delta>();
        }
        return this.delta;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *       &lt;/sequence>
     *       &lt;attribute name="delta_id" type="{http://www.w3.org/2001/XMLSchema}string" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class Delta {

        @XmlAttribute(name = "delta_id")
        protected String deltaId;

        /**
         * Gets the value of the deltaId property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDeltaId() {
            return deltaId;
        }

        /**
         * Sets the value of the deltaId property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDeltaId(String value) {
            this.deltaId = value;
        }

    }

}
