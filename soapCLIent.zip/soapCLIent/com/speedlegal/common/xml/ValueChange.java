
package com.speedlegal.common.xml;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://speedlegal.com/common/xml}Variable"/>
 *         &lt;element name="Answer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Altered" maxOccurs="unbounded" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;extension base="{http://speedlegal.com/common/xml}ValueChangeStatement">
 *                 &lt;sequence>
 *                   &lt;element name="Change">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="From" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="To" type="{http://speedlegal.com/common/xml}StringWithChanges"/>
 *                           &lt;/sequence>
 *                           &lt;attribute name="type" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/extension>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="Removed" type="{http://speedlegal.com/common/xml}ValueChangeStatement" minOccurs="0"/>
 *         &lt;element name="Retained" type="{http://speedlegal.com/common/xml}ValueChangeStatement" minOccurs="0"/>
 *         &lt;element ref="{http://speedlegal.com/common/xml}ChangeComments" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="title" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="resolution" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="resolvedValue" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "variable",
    "answer",
    "altered",
    "removed",
    "retained",
    "changeComments"
})
@XmlRootElement(name = "ValueChange")
public class ValueChange {

    @XmlElement(name = "Variable", required = true)
    protected Variable variable;
    @XmlElement(name = "Answer")
    protected String answer;
    @XmlElement(name = "Altered")
    protected List<ValueChange.Altered> altered;
    @XmlElement(name = "Removed")
    protected ValueChangeStatement removed;
    @XmlElement(name = "Retained")
    protected ValueChangeStatement retained;
    @XmlElement(name = "ChangeComments")
    protected ChangeComments changeComments;
    @XmlAttribute(name = "title")
    protected String title;
    @XmlAttribute(name = "resolution")
    protected String resolution;
    @XmlAttribute(name = "resolvedValue")
    protected String resolvedValue;

    /**
     * Gets the value of the variable property.
     * 
     * @return
     *     possible object is
     *     {@link Variable }
     *     
     */
    public Variable getVariable() {
        return variable;
    }

    /**
     * Sets the value of the variable property.
     * 
     * @param value
     *     allowed object is
     *     {@link Variable }
     *     
     */
    public void setVariable(Variable value) {
        this.variable = value;
    }

    /**
     * Gets the value of the answer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAnswer() {
        return answer;
    }

    /**
     * Sets the value of the answer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAnswer(String value) {
        this.answer = value;
    }

    /**
     * Gets the value of the altered property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the altered property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAltered().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ValueChange.Altered }
     * 
     * 
     */
    public List<ValueChange.Altered> getAltered() {
        if (altered == null) {
            altered = new ArrayList<ValueChange.Altered>();
        }
        return this.altered;
    }

    /**
     * Gets the value of the removed property.
     * 
     * @return
     *     possible object is
     *     {@link ValueChangeStatement }
     *     
     */
    public ValueChangeStatement getRemoved() {
        return removed;
    }

    /**
     * Sets the value of the removed property.
     * 
     * @param value
     *     allowed object is
     *     {@link ValueChangeStatement }
     *     
     */
    public void setRemoved(ValueChangeStatement value) {
        this.removed = value;
    }

    /**
     * Gets the value of the retained property.
     * 
     * @return
     *     possible object is
     *     {@link ValueChangeStatement }
     *     
     */
    public ValueChangeStatement getRetained() {
        return retained;
    }

    /**
     * Sets the value of the retained property.
     * 
     * @param value
     *     allowed object is
     *     {@link ValueChangeStatement }
     *     
     */
    public void setRetained(ValueChangeStatement value) {
        this.retained = value;
    }

    /**
     * Gets the value of the changeComments property.
     * 
     * @return
     *     possible object is
     *     {@link ChangeComments }
     *     
     */
    public ChangeComments getChangeComments() {
        return changeComments;
    }

    /**
     * Sets the value of the changeComments property.
     * 
     * @param value
     *     allowed object is
     *     {@link ChangeComments }
     *     
     */
    public void setChangeComments(ChangeComments value) {
        this.changeComments = value;
    }

    /**
     * Gets the value of the title property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the value of the title property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTitle(String value) {
        this.title = value;
    }

    /**
     * Gets the value of the resolution property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResolution() {
        return resolution;
    }

    /**
     * Sets the value of the resolution property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResolution(String value) {
        this.resolution = value;
    }

    /**
     * Gets the value of the resolvedValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResolvedValue() {
        return resolvedValue;
    }

    /**
     * Sets the value of the resolvedValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResolvedValue(String value) {
        this.resolvedValue = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;extension base="{http://speedlegal.com/common/xml}ValueChangeStatement">
     *       &lt;sequence>
     *         &lt;element name="Change">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="From" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="To" type="{http://speedlegal.com/common/xml}StringWithChanges"/>
     *                 &lt;/sequence>
     *                 &lt;attribute name="type" type="{http://www.w3.org/2001/XMLSchema}string" />
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/extension>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "change"
    })
    public static class Altered
        extends ValueChangeStatement
    {

        @XmlElement(name = "Change", required = true)
        protected ValueChange.Altered.Change change;

        /**
         * Gets the value of the change property.
         * 
         * @return
         *     possible object is
         *     {@link ValueChange.Altered.Change }
         *     
         */
        public ValueChange.Altered.Change getChange() {
            return change;
        }

        /**
         * Sets the value of the change property.
         * 
         * @param value
         *     allowed object is
         *     {@link ValueChange.Altered.Change }
         *     
         */
        public void setChange(ValueChange.Altered.Change value) {
            this.change = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="From" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="To" type="{http://speedlegal.com/common/xml}StringWithChanges"/>
         *       &lt;/sequence>
         *       &lt;attribute name="type" type="{http://www.w3.org/2001/XMLSchema}string" />
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "from",
            "to"
        })
        public static class Change {

            @XmlElement(name = "From", required = true)
            protected String from;
            @XmlElement(name = "To", required = true)
            protected StringWithChanges to;
            @XmlAttribute(name = "type")
            protected String type;

            /**
             * Gets the value of the from property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getFrom() {
                return from;
            }

            /**
             * Sets the value of the from property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setFrom(String value) {
                this.from = value;
            }

            /**
             * Gets the value of the to property.
             * 
             * @return
             *     possible object is
             *     {@link StringWithChanges }
             *     
             */
            public StringWithChanges getTo() {
                return to;
            }

            /**
             * Sets the value of the to property.
             * 
             * @param value
             *     allowed object is
             *     {@link StringWithChanges }
             *     
             */
            public void setTo(StringWithChanges value) {
                this.to = value;
            }

            /**
             * Gets the value of the type property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getType() {
                return type;
            }

            /**
             * Sets the value of the type property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setType(String value) {
                this.type = value;
            }

        }

    }

}
