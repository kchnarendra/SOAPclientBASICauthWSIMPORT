
package com.speedlegal.common.xml;

import java.util.HashMap;
import java.util.Map;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAnyAttribute;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.namespace.QName;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://speedlegal.com/common/xml}Fields" minOccurs="0"/>
 *         &lt;element name="RepeatContext" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                 &lt;/sequence>
 *                 &lt;attribute name="container" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="baseName" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="index" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *                 &lt;attribute name="operation" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="duplicatedBy" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="selectedFrom" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;anyAttribute processContents='skip' namespace='##other'/>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ContainerContext" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                 &lt;/sequence>
 *                 &lt;attribute name="repeatType" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="size" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *                 &lt;anyAttribute processContents='skip' namespace='##other'/>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *       &lt;attribute name="name" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="dataType" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;anyAttribute processContents='skip' namespace='##other'/>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "fields",
    "repeatContext",
    "containerContext"
})
@XmlRootElement(name = "Variable")
public class Variable {

    @XmlElement(name = "Fields")
    protected Fields fields;
    @XmlElement(name = "RepeatContext")
    protected Variable.RepeatContext repeatContext;
    @XmlElement(name = "ContainerContext")
    protected Variable.ContainerContext containerContext;
    @XmlAttribute(name = "name", required = true)
    protected String name;
    @XmlAttribute(name = "dataType")
    protected String dataType;
    @XmlAnyAttribute
    private Map<QName, String> otherAttributes = new HashMap<QName, String>();

    /**
     * Gets the value of the fields property.
     * 
     * @return
     *     possible object is
     *     {@link Fields }
     *     
     */
    public Fields getFields() {
        return fields;
    }

    /**
     * Sets the value of the fields property.
     * 
     * @param value
     *     allowed object is
     *     {@link Fields }
     *     
     */
    public void setFields(Fields value) {
        this.fields = value;
    }

    /**
     * Gets the value of the repeatContext property.
     * 
     * @return
     *     possible object is
     *     {@link Variable.RepeatContext }
     *     
     */
    public Variable.RepeatContext getRepeatContext() {
        return repeatContext;
    }

    /**
     * Sets the value of the repeatContext property.
     * 
     * @param value
     *     allowed object is
     *     {@link Variable.RepeatContext }
     *     
     */
    public void setRepeatContext(Variable.RepeatContext value) {
        this.repeatContext = value;
    }

    /**
     * Gets the value of the containerContext property.
     * 
     * @return
     *     possible object is
     *     {@link Variable.ContainerContext }
     *     
     */
    public Variable.ContainerContext getContainerContext() {
        return containerContext;
    }

    /**
     * Sets the value of the containerContext property.
     * 
     * @param value
     *     allowed object is
     *     {@link Variable.ContainerContext }
     *     
     */
    public void setContainerContext(Variable.ContainerContext value) {
        this.containerContext = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the dataType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataType() {
        return dataType;
    }

    /**
     * Sets the value of the dataType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataType(String value) {
        this.dataType = value;
    }

    /**
     * Gets a map that contains attributes that aren't bound to any typed property on this class.
     * 
     * <p>
     * the map is keyed by the name of the attribute and 
     * the value is the string value of the attribute.
     * 
     * the map returned by this method is live, and you can add new attribute
     * by updating the map directly. Because of this design, there's no setter.
     * 
     * 
     * @return
     *     always non-null
     */
    public Map<QName, String> getOtherAttributes() {
        return otherAttributes;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *       &lt;/sequence>
     *       &lt;attribute name="repeatType" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="size" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
     *       &lt;anyAttribute processContents='skip' namespace='##other'/>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class ContainerContext {

        @XmlAttribute(name = "repeatType")
        protected String repeatType;
        @XmlAttribute(name = "size", required = true)
        protected int size;
        @XmlAnyAttribute
        private Map<QName, String> otherAttributes = new HashMap<QName, String>();

        /**
         * Gets the value of the repeatType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getRepeatType() {
            return repeatType;
        }

        /**
         * Sets the value of the repeatType property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setRepeatType(String value) {
            this.repeatType = value;
        }

        /**
         * Gets the value of the size property.
         * 
         */
        public int getSize() {
            return size;
        }

        /**
         * Sets the value of the size property.
         * 
         */
        public void setSize(int value) {
            this.size = value;
        }

        /**
         * Gets a map that contains attributes that aren't bound to any typed property on this class.
         * 
         * <p>
         * the map is keyed by the name of the attribute and 
         * the value is the string value of the attribute.
         * 
         * the map returned by this method is live, and you can add new attribute
         * by updating the map directly. Because of this design, there's no setter.
         * 
         * 
         * @return
         *     always non-null
         */
        public Map<QName, String> getOtherAttributes() {
            return otherAttributes;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *       &lt;/sequence>
     *       &lt;attribute name="container" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="baseName" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="index" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
     *       &lt;attribute name="operation" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="duplicatedBy" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="selectedFrom" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;anyAttribute processContents='skip' namespace='##other'/>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class RepeatContext {

        @XmlAttribute(name = "container", required = true)
        protected String container;
        @XmlAttribute(name = "baseName", required = true)
        protected String baseName;
        @XmlAttribute(name = "index", required = true)
        protected int index;
        @XmlAttribute(name = "operation")
        protected String operation;
        @XmlAttribute(name = "duplicatedBy")
        protected String duplicatedBy;
        @XmlAttribute(name = "selectedFrom")
        protected String selectedFrom;
        @XmlAnyAttribute
        private Map<QName, String> otherAttributes = new HashMap<QName, String>();

        /**
         * Gets the value of the container property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getContainer() {
            return container;
        }

        /**
         * Sets the value of the container property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setContainer(String value) {
            this.container = value;
        }

        /**
         * Gets the value of the baseName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getBaseName() {
            return baseName;
        }

        /**
         * Sets the value of the baseName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setBaseName(String value) {
            this.baseName = value;
        }

        /**
         * Gets the value of the index property.
         * 
         */
        public int getIndex() {
            return index;
        }

        /**
         * Sets the value of the index property.
         * 
         */
        public void setIndex(int value) {
            this.index = value;
        }

        /**
         * Gets the value of the operation property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getOperation() {
            return operation;
        }

        /**
         * Sets the value of the operation property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setOperation(String value) {
            this.operation = value;
        }

        /**
         * Gets the value of the duplicatedBy property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDuplicatedBy() {
            return duplicatedBy;
        }

        /**
         * Sets the value of the duplicatedBy property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDuplicatedBy(String value) {
            this.duplicatedBy = value;
        }

        /**
         * Gets the value of the selectedFrom property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSelectedFrom() {
            return selectedFrom;
        }

        /**
         * Sets the value of the selectedFrom property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSelectedFrom(String value) {
            this.selectedFrom = value;
        }

        /**
         * Gets a map that contains attributes that aren't bound to any typed property on this class.
         * 
         * <p>
         * the map is keyed by the name of the attribute and 
         * the value is the string value of the attribute.
         * 
         * the map returned by this method is live, and you can add new attribute
         * by updating the map directly. Because of this design, there's no setter.
         * 
         * 
         * @return
         *     always non-null
         */
        public Map<QName, String> getOtherAttributes() {
            return otherAttributes;
        }

    }

}
