@javax.xml.bind.annotation.XmlSchema(namespace = "http://speedlegal.com/common/xml", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.speedlegal.common.xml;
