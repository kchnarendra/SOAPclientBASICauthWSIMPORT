
package com.speedlegal.common.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://speedlegal.com/common/xml}delta"/>
 *         &lt;element ref="{http://speedlegal.com/common/xml}DeltaReport" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="targetResource" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "delta",
    "deltaReport"
})
@XmlRootElement(name = "Amendments")
public class Amendments {

    @XmlElement(required = true)
    protected Delta delta;
    @XmlElement(name = "DeltaReport")
    protected DeltaReport deltaReport;
    @XmlAttribute(name = "targetResource")
    protected String targetResource;

    /**
     * Gets the value of the delta property.
     * 
     * @return
     *     possible object is
     *     {@link Delta }
     *     
     */
    public Delta getDelta() {
        return delta;
    }

    /**
     * Sets the value of the delta property.
     * 
     * @param value
     *     allowed object is
     *     {@link Delta }
     *     
     */
    public void setDelta(Delta value) {
        this.delta = value;
    }

    /**
     * Gets the value of the deltaReport property.
     * 
     * @return
     *     possible object is
     *     {@link DeltaReport }
     *     
     */
    public DeltaReport getDeltaReport() {
        return deltaReport;
    }

    /**
     * Sets the value of the deltaReport property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeltaReport }
     *     
     */
    public void setDeltaReport(DeltaReport value) {
        this.deltaReport = value;
    }

    /**
     * Gets the value of the targetResource property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTargetResource() {
        return targetResource;
    }

    /**
     * Sets the value of the targetResource property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTargetResource(String value) {
        this.targetResource = value;
    }

}
