
package com.speedlegal.common.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Action complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Action">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Heading" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Comment" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="JavaFunction" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="ClassName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="MethodName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element ref="{http://speedlegal.com/common/xml}ParameterMap" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="SmartFunction" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="FunctionName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element ref="{http://speedlegal.com/common/xml}ParameterMap" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *       &lt;attribute name="runAsync" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Action", propOrder = {
    "heading",
    "comment",
    "javaFunction",
    "smartFunction"
})
public class Action {

    @XmlElement(name = "Heading")
    protected String heading;
    @XmlElement(name = "Comment")
    protected String comment;
    @XmlElement(name = "JavaFunction")
    protected Action.JavaFunction javaFunction;
    @XmlElement(name = "SmartFunction")
    protected Action.SmartFunction smartFunction;
    @XmlAttribute(name = "runAsync")
    protected Boolean runAsync;

    /**
     * Gets the value of the heading property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHeading() {
        return heading;
    }

    /**
     * Sets the value of the heading property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHeading(String value) {
        this.heading = value;
    }

    /**
     * Gets the value of the comment property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComment() {
        return comment;
    }

    /**
     * Sets the value of the comment property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComment(String value) {
        this.comment = value;
    }

    /**
     * Gets the value of the javaFunction property.
     * 
     * @return
     *     possible object is
     *     {@link Action.JavaFunction }
     *     
     */
    public Action.JavaFunction getJavaFunction() {
        return javaFunction;
    }

    /**
     * Sets the value of the javaFunction property.
     * 
     * @param value
     *     allowed object is
     *     {@link Action.JavaFunction }
     *     
     */
    public void setJavaFunction(Action.JavaFunction value) {
        this.javaFunction = value;
    }

    /**
     * Gets the value of the smartFunction property.
     * 
     * @return
     *     possible object is
     *     {@link Action.SmartFunction }
     *     
     */
    public Action.SmartFunction getSmartFunction() {
        return smartFunction;
    }

    /**
     * Sets the value of the smartFunction property.
     * 
     * @param value
     *     allowed object is
     *     {@link Action.SmartFunction }
     *     
     */
    public void setSmartFunction(Action.SmartFunction value) {
        this.smartFunction = value;
    }

    /**
     * Gets the value of the runAsync property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRunAsync() {
        return runAsync;
    }

    /**
     * Sets the value of the runAsync property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRunAsync(Boolean value) {
        this.runAsync = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="ClassName" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="MethodName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *         &lt;element ref="{http://speedlegal.com/common/xml}ParameterMap" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "className",
        "methodName",
        "parameterMap"
    })
    public static class JavaFunction {

        @XmlElement(name = "ClassName", required = true)
        protected String className;
        @XmlElement(name = "MethodName")
        protected String methodName;
        @XmlElement(name = "ParameterMap")
        protected ParameterMap parameterMap;

        /**
         * Gets the value of the className property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getClassName() {
            return className;
        }

        /**
         * Sets the value of the className property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setClassName(String value) {
            this.className = value;
        }

        /**
         * Gets the value of the methodName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMethodName() {
            return methodName;
        }

        /**
         * Sets the value of the methodName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMethodName(String value) {
            this.methodName = value;
        }

        /**
         * Gets the value of the parameterMap property.
         * 
         * @return
         *     possible object is
         *     {@link ParameterMap }
         *     
         */
        public ParameterMap getParameterMap() {
            return parameterMap;
        }

        /**
         * Sets the value of the parameterMap property.
         * 
         * @param value
         *     allowed object is
         *     {@link ParameterMap }
         *     
         */
        public void setParameterMap(ParameterMap value) {
            this.parameterMap = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="FunctionName" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element ref="{http://speedlegal.com/common/xml}ParameterMap" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "functionName",
        "parameterMap"
    })
    public static class SmartFunction {

        @XmlElement(name = "FunctionName", required = true)
        protected String functionName;
        @XmlElement(name = "ParameterMap")
        protected ParameterMap parameterMap;

        /**
         * Gets the value of the functionName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getFunctionName() {
            return functionName;
        }

        /**
         * Sets the value of the functionName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setFunctionName(String value) {
            this.functionName = value;
        }

        /**
         * Gets the value of the parameterMap property.
         * 
         * @return
         *     possible object is
         *     {@link ParameterMap }
         *     
         */
        public ParameterMap getParameterMap() {
            return parameterMap;
        }

        /**
         * Sets the value of the parameterMap property.
         * 
         * @param value
         *     allowed object is
         *     {@link ParameterMap }
         *     
         */
        public void setParameterMap(ParameterMap value) {
            this.parameterMap = value;
        }

    }

}
