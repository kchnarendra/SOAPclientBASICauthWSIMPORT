
package com.speedlegal.common.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://speedlegal.com/common/xml}inserts"/>
 *         &lt;element ref="{http://speedlegal.com/common/xml}deletes"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "inserts",
    "deletes"
})
@XmlRootElement(name = "delta")
public class Delta {

    @XmlElement(required = true)
    protected Inserts inserts;
    @XmlElement(required = true)
    protected Deletes deletes;

    /**
     * Gets the value of the inserts property.
     * 
     * @return
     *     possible object is
     *     {@link Inserts }
     *     
     */
    public Inserts getInserts() {
        return inserts;
    }

    /**
     * Sets the value of the inserts property.
     * 
     * @param value
     *     allowed object is
     *     {@link Inserts }
     *     
     */
    public void setInserts(Inserts value) {
        this.inserts = value;
    }

    /**
     * Gets the value of the deletes property.
     * 
     * @return
     *     possible object is
     *     {@link Deletes }
     *     
     */
    public Deletes getDeletes() {
        return deletes;
    }

    /**
     * Sets the value of the deletes property.
     * 
     * @param value
     *     allowed object is
     *     {@link Deletes }
     *     
     */
    public void setDeletes(Deletes value) {
        this.deletes = value;
    }

}
