
package com.speedlegal.common.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PrintDocument" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Notes" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="CompletionInstructions" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="EditorialNotes" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="InterviewRecord" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="WriteProtect" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="TableOfContents" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="XMLPrettyPrint" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Format" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="StartInterview" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ConciseResponse" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ConciseIncludeReset" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="StyleDirectory" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmbedRoundTripData" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="WithAmendments" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="EditSummary" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="PDFShowChanges" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "printDocument",
    "notes",
    "completionInstructions",
    "editorialNotes",
    "interviewRecord",
    "writeProtect",
    "tableOfContents",
    "xmlPrettyPrint",
    "format",
    "startInterview",
    "conciseResponse",
    "conciseIncludeReset",
    "styleDirectory",
    "embedRoundTripData",
    "withAmendments",
    "editSummary",
    "pdfShowChanges"
})
@XmlRootElement(name = "OutputPreferences")
public class OutputPreferences {

    @XmlElement(name = "PrintDocument", defaultValue = "true")
    protected Boolean printDocument;
    @XmlElement(name = "Notes", defaultValue = "false")
    protected Boolean notes;
    @XmlElement(name = "CompletionInstructions", defaultValue = "false")
    protected Boolean completionInstructions;
    @XmlElement(name = "EditorialNotes", defaultValue = "false")
    protected Boolean editorialNotes;
    @XmlElement(name = "InterviewRecord", defaultValue = "false")
    protected Boolean interviewRecord;
    @XmlElement(name = "WriteProtect", defaultValue = "false")
    protected Boolean writeProtect;
    @XmlElement(name = "TableOfContents", defaultValue = "false")
    protected Boolean tableOfContents;
    @XmlElement(name = "XMLPrettyPrint", defaultValue = "false")
    protected Boolean xmlPrettyPrint;
    @XmlElement(name = "Format", required = true, defaultValue = "PDF")
    protected String format;
    @XmlElement(name = "StartInterview", defaultValue = "false")
    protected Boolean startInterview;
    @XmlElement(name = "ConciseResponse", defaultValue = "false")
    protected Boolean conciseResponse;
    @XmlElement(name = "ConciseIncludeReset", defaultValue = "false")
    protected Boolean conciseIncludeReset;
    @XmlElement(name = "StyleDirectory")
    protected String styleDirectory;
    @XmlElement(name = "EmbedRoundTripData", defaultValue = "false")
    protected Boolean embedRoundTripData;
    @XmlElement(name = "WithAmendments", defaultValue = "false")
    protected Boolean withAmendments;
    @XmlElement(name = "EditSummary", defaultValue = "false")
    protected Boolean editSummary;
    @XmlElement(name = "PDFShowChanges", defaultValue = "false")
    protected Boolean pdfShowChanges;

    /**
     * Gets the value of the printDocument property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isPrintDocument() {
        return printDocument;
    }

    /**
     * Sets the value of the printDocument property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPrintDocument(Boolean value) {
        this.printDocument = value;
    }

    /**
     * Gets the value of the notes property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isNotes() {
        return notes;
    }

    /**
     * Sets the value of the notes property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setNotes(Boolean value) {
        this.notes = value;
    }

    /**
     * Gets the value of the completionInstructions property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCompletionInstructions() {
        return completionInstructions;
    }

    /**
     * Sets the value of the completionInstructions property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCompletionInstructions(Boolean value) {
        this.completionInstructions = value;
    }

    /**
     * Gets the value of the editorialNotes property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isEditorialNotes() {
        return editorialNotes;
    }

    /**
     * Sets the value of the editorialNotes property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setEditorialNotes(Boolean value) {
        this.editorialNotes = value;
    }

    /**
     * Gets the value of the interviewRecord property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isInterviewRecord() {
        return interviewRecord;
    }

    /**
     * Sets the value of the interviewRecord property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setInterviewRecord(Boolean value) {
        this.interviewRecord = value;
    }

    /**
     * Gets the value of the writeProtect property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isWriteProtect() {
        return writeProtect;
    }

    /**
     * Sets the value of the writeProtect property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setWriteProtect(Boolean value) {
        this.writeProtect = value;
    }

    /**
     * Gets the value of the tableOfContents property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isTableOfContents() {
        return tableOfContents;
    }

    /**
     * Sets the value of the tableOfContents property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setTableOfContents(Boolean value) {
        this.tableOfContents = value;
    }

    /**
     * Gets the value of the xmlPrettyPrint property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isXMLPrettyPrint() {
        return xmlPrettyPrint;
    }

    /**
     * Sets the value of the xmlPrettyPrint property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setXMLPrettyPrint(Boolean value) {
        this.xmlPrettyPrint = value;
    }

    /**
     * Gets the value of the format property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormat() {
        return format;
    }

    /**
     * Sets the value of the format property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormat(String value) {
        this.format = value;
    }

    /**
     * Gets the value of the startInterview property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isStartInterview() {
        return startInterview;
    }

    /**
     * Sets the value of the startInterview property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setStartInterview(Boolean value) {
        this.startInterview = value;
    }

    /**
     * Gets the value of the conciseResponse property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isConciseResponse() {
        return conciseResponse;
    }

    /**
     * Sets the value of the conciseResponse property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setConciseResponse(Boolean value) {
        this.conciseResponse = value;
    }

    /**
     * Gets the value of the conciseIncludeReset property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isConciseIncludeReset() {
        return conciseIncludeReset;
    }

    /**
     * Sets the value of the conciseIncludeReset property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setConciseIncludeReset(Boolean value) {
        this.conciseIncludeReset = value;
    }

    /**
     * Gets the value of the styleDirectory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStyleDirectory() {
        return styleDirectory;
    }

    /**
     * Sets the value of the styleDirectory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStyleDirectory(String value) {
        this.styleDirectory = value;
    }

    /**
     * Gets the value of the embedRoundTripData property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isEmbedRoundTripData() {
        return embedRoundTripData;
    }

    /**
     * Sets the value of the embedRoundTripData property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setEmbedRoundTripData(Boolean value) {
        this.embedRoundTripData = value;
    }

    /**
     * Gets the value of the withAmendments property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isWithAmendments() {
        return withAmendments;
    }

    /**
     * Sets the value of the withAmendments property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setWithAmendments(Boolean value) {
        this.withAmendments = value;
    }

    /**
     * Gets the value of the editSummary property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isEditSummary() {
        return editSummary;
    }

    /**
     * Sets the value of the editSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setEditSummary(Boolean value) {
        this.editSummary = value;
    }

    /**
     * Gets the value of the pdfShowChanges property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isPDFShowChanges() {
        return pdfShowChanges;
    }

    /**
     * Sets the value of the pdfShowChanges property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPDFShowChanges(Boolean value) {
        this.pdfShowChanges = value;
    }

}
