
package com.speedlegal.common.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ResourceMigrationWorkflow complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ResourceMigrationWorkflow">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ExportPrepare" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
 *         &lt;element name="ImportPrepare" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
 *         &lt;element name="ImportComplete" type="{http://speedlegal.com/common/xml}Action" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ResourceMigrationWorkflow", propOrder = {
    "exportPrepare",
    "importPrepare",
    "importComplete"
})
public class ResourceMigrationWorkflow {

    @XmlElement(name = "ExportPrepare")
    protected Action exportPrepare;
    @XmlElement(name = "ImportPrepare")
    protected Action importPrepare;
    @XmlElement(name = "ImportComplete")
    protected Action importComplete;

    /**
     * Gets the value of the exportPrepare property.
     * 
     * @return
     *     possible object is
     *     {@link Action }
     *     
     */
    public Action getExportPrepare() {
        return exportPrepare;
    }

    /**
     * Sets the value of the exportPrepare property.
     * 
     * @param value
     *     allowed object is
     *     {@link Action }
     *     
     */
    public void setExportPrepare(Action value) {
        this.exportPrepare = value;
    }

    /**
     * Gets the value of the importPrepare property.
     * 
     * @return
     *     possible object is
     *     {@link Action }
     *     
     */
    public Action getImportPrepare() {
        return importPrepare;
    }

    /**
     * Sets the value of the importPrepare property.
     * 
     * @param value
     *     allowed object is
     *     {@link Action }
     *     
     */
    public void setImportPrepare(Action value) {
        this.importPrepare = value;
    }

    /**
     * Gets the value of the importComplete property.
     * 
     * @return
     *     possible object is
     *     {@link Action }
     *     
     */
    public Action getImportComplete() {
        return importComplete;
    }

    /**
     * Sets the value of the importComplete property.
     * 
     * @param value
     *     allowed object is
     *     {@link Action }
     *     
     */
    public void setImportComplete(Action value) {
        this.importComplete = value;
    }

}
