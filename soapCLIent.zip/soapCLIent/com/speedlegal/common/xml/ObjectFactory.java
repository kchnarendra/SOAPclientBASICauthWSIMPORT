
package com.speedlegal.common.xml;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.speedlegal.common.xml package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Insert_QNAME = new QName("http://speedlegal.com/common/xml", "insert");
    private final static QName _AllowedAnswer_QNAME = new QName("http://speedlegal.com/common/xml", "AllowedAnswer");
    private final static QName _QuestionText_QNAME = new QName("http://speedlegal.com/common/xml", "QuestionText");
    private final static QName _Delete_QNAME = new QName("http://speedlegal.com/common/xml", "delete");
    private final static QName _ExampleText_QNAME = new QName("http://speedlegal.com/common/xml", "ExampleText");
    private final static QName _StringWithChangesInserted_QNAME = new QName("http://speedlegal.com/common/xml", "inserted");
    private final static QName _StringWithChangesDeleted_QNAME = new QName("http://speedlegal.com/common/xml", "deleted");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.speedlegal.common.xml
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SourceInfo }
     * 
     */
    public SourceInfo createSourceInfo() {
        return new SourceInfo();
    }

    /**
     * Create an instance of {@link Variable }
     * 
     */
    public Variable createVariable() {
        return new Variable();
    }

    /**
     * Create an instance of {@link Question }
     * 
     */
    public Question createQuestion() {
        return new Question();
    }

    /**
     * Create an instance of {@link TextChange }
     * 
     */
    public TextChange createTextChange() {
        return new TextChange();
    }

    /**
     * Create an instance of {@link ValueChange }
     * 
     */
    public ValueChange createValueChange() {
        return new ValueChange();
    }

    /**
     * Create an instance of {@link Workflow }
     * 
     */
    public Workflow createWorkflow() {
        return new Workflow();
    }

    /**
     * Create an instance of {@link ParameterMap }
     * 
     */
    public ParameterMap createParameterMap() {
        return new ParameterMap();
    }

    /**
     * Create an instance of {@link Action }
     * 
     */
    public Action createAction() {
        return new Action();
    }

    /**
     * Create an instance of {@link InsertableUsage }
     * 
     */
    public InsertableUsage createInsertableUsage() {
        return new InsertableUsage();
    }

    /**
     * Create an instance of {@link AnswerMap }
     * 
     */
    public AnswerMap createAnswerMap() {
        return new AnswerMap();
    }

    /**
     * Create an instance of {@link ValueChange.Altered }
     * 
     */
    public ValueChange.Altered createValueChangeAltered() {
        return new ValueChange.Altered();
    }

    /**
     * Create an instance of {@link TextChangeStatement }
     * 
     */
    public TextChangeStatement createTextChangeStatement() {
        return new TextChangeStatement();
    }

    /**
     * Create an instance of {@link SourceInfo.Engine }
     * 
     */
    public SourceInfo.Engine createSourceInfoEngine() {
        return new SourceInfo.Engine();
    }

    /**
     * Create an instance of {@link SourceInfo.Resource }
     * 
     */
    public SourceInfo.Resource createSourceInfoResource() {
        return new SourceInfo.Resource();
    }

    /**
     * Create an instance of {@link Fields }
     * 
     */
    public Fields createFields() {
        return new Fields();
    }

    /**
     * Create an instance of {@link Field }
     * 
     */
    public Field createField() {
        return new Field();
    }

    /**
     * Create an instance of {@link Response }
     * 
     */
    public Response createResponse() {
        return new Response();
    }

    /**
     * Create an instance of {@link Variable.RepeatContext }
     * 
     */
    public Variable.RepeatContext createVariableRepeatContext() {
        return new Variable.RepeatContext();
    }

    /**
     * Create an instance of {@link Variable.ContainerContext }
     * 
     */
    public Variable.ContainerContext createVariableContainerContext() {
        return new Variable.ContainerContext();
    }

    /**
     * Create an instance of {@link AvailableAnswer }
     * 
     */
    public AvailableAnswer createAvailableAnswer() {
        return new AvailableAnswer();
    }

    /**
     * Create an instance of {@link Note }
     * 
     */
    public Note createNote() {
        return new Note();
    }

    /**
     * Create an instance of {@link Question.Context }
     * 
     */
    public Question.Context createQuestionContext() {
        return new Question.Context();
    }

    /**
     * Create an instance of {@link Amendments }
     * 
     */
    public Amendments createAmendments() {
        return new Amendments();
    }

    /**
     * Create an instance of {@link com.speedlegal.common.xml.Delta }
     * 
     */
    public com.speedlegal.common.xml.Delta createDelta() {
        return new com.speedlegal.common.xml.Delta();
    }

    /**
     * Create an instance of {@link Inserts }
     * 
     */
    public Inserts createInserts() {
        return new Inserts();
    }

    /**
     * Create an instance of {@link Patch }
     * 
     */
    public Patch createPatch() {
        return new Patch();
    }

    /**
     * Create an instance of {@link Deletes }
     * 
     */
    public Deletes createDeletes() {
        return new Deletes();
    }

    /**
     * Create an instance of {@link DeltaReport }
     * 
     */
    public DeltaReport createDeltaReport() {
        return new DeltaReport();
    }

    /**
     * Create an instance of {@link TextChange.MetaReference }
     * 
     */
    public TextChange.MetaReference createTextChangeMetaReference() {
        return new TextChange.MetaReference();
    }

    /**
     * Create an instance of {@link ChangeComments }
     * 
     */
    public ChangeComments createChangeComments() {
        return new ChangeComments();
    }

    /**
     * Create an instance of {@link Comment }
     * 
     */
    public Comment createComment() {
        return new Comment();
    }

    /**
     * Create an instance of {@link ValueChangeStatement }
     * 
     */
    public ValueChangeStatement createValueChangeStatement() {
        return new ValueChangeStatement();
    }

    /**
     * Create an instance of {@link OutputPreferences }
     * 
     */
    public OutputPreferences createOutputPreferences() {
        return new OutputPreferences();
    }

    /**
     * Create an instance of {@link Workflow.DocumentDetails }
     * 
     */
    public Workflow.DocumentDetails createWorkflowDocumentDetails() {
        return new Workflow.DocumentDetails();
    }

    /**
     * Create an instance of {@link ResourceMigrationWorkflow }
     * 
     */
    public ResourceMigrationWorkflow createResourceMigrationWorkflow() {
        return new ResourceMigrationWorkflow();
    }

    /**
     * Create an instance of {@link Workflow.InterviewPrepare }
     * 
     */
    public Workflow.InterviewPrepare createWorkflowInterviewPrepare() {
        return new Workflow.InterviewPrepare();
    }

    /**
     * Create an instance of {@link Workflow.InterviewRound }
     * 
     */
    public Workflow.InterviewRound createWorkflowInterviewRound() {
        return new Workflow.InterviewRound();
    }

    /**
     * Create an instance of {@link Workflow.AnswerManagement }
     * 
     */
    public Workflow.AnswerManagement createWorkflowAnswerManagement() {
        return new Workflow.AnswerManagement();
    }

    /**
     * Create an instance of {@link Workflow.ActiveTextPreview }
     * 
     */
    public Workflow.ActiveTextPreview createWorkflowActiveTextPreview() {
        return new Workflow.ActiveTextPreview();
    }

    /**
     * Create an instance of {@link Workflow.OutputOptions }
     * 
     */
    public Workflow.OutputOptions createWorkflowOutputOptions() {
        return new Workflow.OutputOptions();
    }

    /**
     * Create an instance of {@link Workflow.InterviewCommon }
     * 
     */
    public Workflow.InterviewCommon createWorkflowInterviewCommon() {
        return new Workflow.InterviewCommon();
    }

    /**
     * Create an instance of {@link AnswerRecord }
     * 
     */
    public AnswerRecord createAnswerRecord() {
        return new AnswerRecord();
    }

    /**
     * Create an instance of {@link WorkflowSchemes }
     * 
     */
    public WorkflowSchemes createWorkflowSchemes() {
        return new WorkflowSchemes();
    }

    /**
     * Create an instance of {@link WorkflowScheme }
     * 
     */
    public WorkflowScheme createWorkflowScheme() {
        return new WorkflowScheme();
    }

    /**
     * Create an instance of {@link AuditEvent }
     * 
     */
    public AuditEvent createAuditEvent() {
        return new AuditEvent();
    }

    /**
     * Create an instance of {@link AuditTrail }
     * 
     */
    public AuditTrail createAuditTrail() {
        return new AuditTrail();
    }

    /**
     * Create an instance of {@link ParameterMap.Entry }
     * 
     */
    public ParameterMap.Entry createParameterMapEntry() {
        return new ParameterMap.Entry();
    }

    /**
     * Create an instance of {@link RepositoryProperty }
     * 
     */
    public RepositoryProperty createRepositoryProperty() {
        return new RepositoryProperty();
    }

    /**
     * Create an instance of {@link StringWithChanges }
     * 
     */
    public StringWithChanges createStringWithChanges() {
        return new StringWithChanges();
    }

    /**
     * Create an instance of {@link Action.JavaFunction }
     * 
     */
    public Action.JavaFunction createActionJavaFunction() {
        return new Action.JavaFunction();
    }

    /**
     * Create an instance of {@link Action.SmartFunction }
     * 
     */
    public Action.SmartFunction createActionSmartFunction() {
        return new Action.SmartFunction();
    }

    /**
     * Create an instance of {@link InsertableUsage.Delta }
     * 
     */
    public InsertableUsage.Delta createInsertableUsageDelta() {
        return new InsertableUsage.Delta();
    }

    /**
     * Create an instance of {@link AnswerMap.Entry }
     * 
     */
    public AnswerMap.Entry createAnswerMapEntry() {
        return new AnswerMap.Entry();
    }

    /**
     * Create an instance of {@link ValueChange.Altered.Change }
     * 
     */
    public ValueChange.Altered.Change createValueChangeAlteredChange() {
        return new ValueChange.Altered.Change();
    }

    /**
     * Create an instance of {@link TextChangeStatement.Delta }
     * 
     */
    public TextChangeStatement.Delta createTextChangeStatementDelta() {
        return new TextChangeStatement.Delta();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Patch }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://speedlegal.com/common/xml", name = "insert")
    public JAXBElement<Patch> createInsert(Patch value) {
        return new JAXBElement<Patch>(_Insert_QNAME, Patch.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AvailableAnswer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://speedlegal.com/common/xml", name = "AllowedAnswer")
    public JAXBElement<AvailableAnswer> createAllowedAnswer(AvailableAnswer value) {
        return new JAXBElement<AvailableAnswer>(_AllowedAnswer_QNAME, AvailableAnswer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://speedlegal.com/common/xml", name = "QuestionText")
    public JAXBElement<String> createQuestionText(String value) {
        return new JAXBElement<String>(_QuestionText_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Patch }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://speedlegal.com/common/xml", name = "delete")
    public JAXBElement<Patch> createDelete(Patch value) {
        return new JAXBElement<Patch>(_Delete_QNAME, Patch.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://speedlegal.com/common/xml", name = "ExampleText")
    public JAXBElement<String> createExampleText(String value) {
        return new JAXBElement<String>(_ExampleText_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://speedlegal.com/common/xml", name = "inserted", scope = StringWithChanges.class)
    public JAXBElement<String> createStringWithChangesInserted(String value) {
        return new JAXBElement<String>(_StringWithChangesInserted_QNAME, String.class, StringWithChanges.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://speedlegal.com/common/xml", name = "deleted", scope = StringWithChanges.class)
    public JAXBElement<String> createStringWithChangesDeleted(String value) {
        return new JAXBElement<String>(_StringWithChangesDeleted_QNAME, String.class, StringWithChanges.class, value);
    }

}
