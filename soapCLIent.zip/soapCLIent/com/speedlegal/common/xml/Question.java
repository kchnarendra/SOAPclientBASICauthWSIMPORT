
package com.speedlegal.common.xml;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://speedlegal.com/common/xml}Variable"/>
 *         &lt;element name="QuestionText" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ExampleText" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AllowedAnswer" type="{http://speedlegal.com/common/xml}AvailableAnswer" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="DefaultAnswer" type="{http://speedlegal.com/common/xml}AvailableAnswer" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://speedlegal.com/common/xml}Note" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Context" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element ref="{http://speedlegal.com/common/xml}Variable"/>
 *                   &lt;element name="Narrative" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *       &lt;attribute name="topic" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="priority" type="{http://www.w3.org/2001/XMLSchema}double" />
 *       &lt;attribute name="multipleAnswers" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="questionType" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="layout" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "variable",
    "questionText",
    "exampleText",
    "allowedAnswer",
    "defaultAnswer",
    "note",
    "context"
})
@XmlRootElement(name = "Question")
public class Question {

    @XmlElement(name = "Variable", required = true)
    protected Variable variable;
    @XmlElement(name = "QuestionText", required = true)
    protected String questionText;
    @XmlElement(name = "ExampleText")
    protected String exampleText;
    @XmlElement(name = "AllowedAnswer")
    protected List<AvailableAnswer> allowedAnswer;
    @XmlElement(name = "DefaultAnswer")
    protected List<AvailableAnswer> defaultAnswer;
    @XmlElement(name = "Note")
    protected List<Note> note;
    @XmlElement(name = "Context")
    protected Question.Context context;
    @XmlAttribute(name = "topic")
    protected String topic;
    @XmlAttribute(name = "priority")
    protected Double priority;
    @XmlAttribute(name = "multipleAnswers")
    protected Boolean multipleAnswers;
    @XmlAttribute(name = "questionType")
    protected String questionType;
    @XmlAttribute(name = "layout")
    protected String layout;

    /**
     * Gets the value of the variable property.
     * 
     * @return
     *     possible object is
     *     {@link Variable }
     *     
     */
    public Variable getVariable() {
        return variable;
    }

    /**
     * Sets the value of the variable property.
     * 
     * @param value
     *     allowed object is
     *     {@link Variable }
     *     
     */
    public void setVariable(Variable value) {
        this.variable = value;
    }

    /**
     * Gets the value of the questionText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQuestionText() {
        return questionText;
    }

    /**
     * Sets the value of the questionText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQuestionText(String value) {
        this.questionText = value;
    }

    /**
     * Gets the value of the exampleText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExampleText() {
        return exampleText;
    }

    /**
     * Sets the value of the exampleText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExampleText(String value) {
        this.exampleText = value;
    }

    /**
     * Gets the value of the allowedAnswer property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the allowedAnswer property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAllowedAnswer().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AvailableAnswer }
     * 
     * 
     */
    public List<AvailableAnswer> getAllowedAnswer() {
        if (allowedAnswer == null) {
            allowedAnswer = new ArrayList<AvailableAnswer>();
        }
        return this.allowedAnswer;
    }

    /**
     * Gets the value of the defaultAnswer property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the defaultAnswer property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDefaultAnswer().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AvailableAnswer }
     * 
     * 
     */
    public List<AvailableAnswer> getDefaultAnswer() {
        if (defaultAnswer == null) {
            defaultAnswer = new ArrayList<AvailableAnswer>();
        }
        return this.defaultAnswer;
    }

    /**
     * Gets the value of the note property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the note property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNote().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Note }
     * 
     * 
     */
    public List<Note> getNote() {
        if (note == null) {
            note = new ArrayList<Note>();
        }
        return this.note;
    }

    /**
     * Gets the value of the context property.
     * 
     * @return
     *     possible object is
     *     {@link Question.Context }
     *     
     */
    public Question.Context getContext() {
        return context;
    }

    /**
     * Sets the value of the context property.
     * 
     * @param value
     *     allowed object is
     *     {@link Question.Context }
     *     
     */
    public void setContext(Question.Context value) {
        this.context = value;
    }

    /**
     * Gets the value of the topic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTopic() {
        return topic;
    }

    /**
     * Sets the value of the topic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTopic(String value) {
        this.topic = value;
    }

    /**
     * Gets the value of the priority property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setPriority(Double value) {
        this.priority = value;
    }

    /**
     * Gets the value of the multipleAnswers property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isMultipleAnswers() {
        return multipleAnswers;
    }

    /**
     * Sets the value of the multipleAnswers property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setMultipleAnswers(Boolean value) {
        this.multipleAnswers = value;
    }

    /**
     * Gets the value of the questionType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQuestionType() {
        return questionType;
    }

    /**
     * Sets the value of the questionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQuestionType(String value) {
        this.questionType = value;
    }

    /**
     * Gets the value of the layout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLayout() {
        return layout;
    }

    /**
     * Sets the value of the layout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLayout(String value) {
        this.layout = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element ref="{http://speedlegal.com/common/xml}Variable"/>
     *         &lt;element name="Narrative" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "variable",
        "narrative"
    })
    public static class Context {

        @XmlElement(name = "Variable", required = true)
        protected Variable variable;
        @XmlElement(name = "Narrative")
        protected String narrative;

        /**
         * Gets the value of the variable property.
         * 
         * @return
         *     possible object is
         *     {@link Variable }
         *     
         */
        public Variable getVariable() {
            return variable;
        }

        /**
         * Sets the value of the variable property.
         * 
         * @param value
         *     allowed object is
         *     {@link Variable }
         *     
         */
        public void setVariable(Variable value) {
            this.variable = value;
        }

        /**
         * Gets the value of the narrative property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getNarrative() {
            return narrative;
        }

        /**
         * Sets the value of the narrative property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setNarrative(String value) {
            this.narrative = value;
        }

    }

}
