package com.narendra;

import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.util.List;

import com.speedlegal.evaluator.facade.params.DescribePreferences;
import com.speedlegal.evaluator.facade.params.DescribeRequest;
import com.speedlegal.evaluator.facade.params.DescribeResponse;
import com.speedlegal.evaluator.facade.params.Document;
import com.speedlegal.evaluator.facade.params.LogicItem;
import com.speedlegal.evaluator.facade.service.Evaluation;
import com.speedlegal.evaluator.facade.service.EvaluationService;


public class App {

    static class BasicAuthenticator extends Authenticator {
        String baName;
        String baPassword;
        private BasicAuthenticator(String baName1, String baPassword1) {
            baName = baName1;
            baPassword = baPassword1;
        }
        @Override
            public PasswordAuthentication getPasswordAuthentication() {
                System.out.println("Authenticating...");
                return new PasswordAuthentication(baName, baPassword.toCharArray());
            }
    };
    
	
	public static void main(String[] args) {
		
        String name = "ethienuser";
        String password = "Eth13n!";
        Authenticator.setDefault(new BasicAuthenticator(name, password));
		
		
		EvaluationService evaluationService = new EvaluationService();
		Evaluation evaluation = evaluationService.getEvaluation();
		
		
	
		
		/*((Stub)evaluation).setUsername("author");
		((Stub)evaluation).setPassword("author");*/ 
		
		DescribeRequest describeRequest = createDescribeResponseObj();
		
		DescribeResponse describeResponse = evaluation.describe(describeRequest);
		System.out.println(describeResponse);
		
		List<LogicItem> logicItem = describeResponse.getLogicItems().getLogicItem();
		
		for (int i = 0; i < logicItem.size(); i++) {
			LogicItem item = logicItem.get(i);
			//System.out.println("EXAMPLE TEXT: "+item.getExampleText() + "QUESTION Text: " + item.getQuestionText() + "ALLOWED AND: " + item.getAllowedAnswer().toString());
			System.out.println("TOPIC: "+ item.getTopic() + "   --   TYPE: " + item.getType());
		}

	}

	private static DescribeRequest createDescribeResponseObj() {
		
		DescribeRequest request = new DescribeRequest();
		Document document = new Document();
		//document.setResourcePath("/files/Ethien/lease liability report 10 10 18.xml");
		document.setResourcePath("/files/Ethien/lease liability report 10 10 18.xml");
		request.setDocument(document);
		
		DescribePreferences describePreferences = new DescribePreferences();
		describePreferences.setIncludeDataTypes(true);
		describePreferences.setIncludeLogicDetail(true);
		describePreferences.setIncludeLogicItems(true);
		describePreferences.setIncludeMetaInfo(true);
		describePreferences.setIncludeReferences(true);
		request.setDescribePreferences(describePreferences);
		
		return request;
	}
}
