@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.w3.org/2005/05/xmlmime")
package org.w3._2005._05.xmlmime;
